/**
 * ADMIN PANEL - PRZYKŁADOWA KONFIGURACJA
 * 
 * Skopiuj ten plik do swojego projektu jako:
 * client/src/config/admin-config.ts
 * 
 * Dostosuj wartości do swoich potrzeb.
 */

export const adminConfig = {
  /**
   * Nazwa aplikacji wyświetlana w panelu admin
   */
  appName: "BabatvFanPage",

  /**
   * Menu nawigacyjne - włącz/wyłącz zakładki
   */
  features: {
    dashboard: true,
    users: true,
    messages: true,
    ads: true,
    testimonials: true,
    playlist: false,        // Wyłączone dla fan page
    socialMedia: true,
    theme: true,
  },

  /**
   * Role użytkowników
   */
  roles: {
    ADMIN: "ADMIN",        // Pełny dostęp
    EDITOR: "EDITOR",      // Ograniczony dostęp (bez usuwania)
    USER: "USER",          // Zwykły użytkownik
  },

  /**
   * Dashboard KPI - które metryki pokazywać
   */
  dashboard: {
    showRevenue: true,
    showUserCount: true,
    showActiveUsers: true,
    showTransactions: true,
    showCharts: true,
  },

  /**
   * Mass Messaging - integracje
   */
  messaging: {
    email: {
      enabled: false,      // Zmień na true po skonfigurowaniu SendGrid
      provider: "sendgrid",
      from: "noreply@babatv.de",
    },
    sms: {
      enabled: false,      // Zmień na true po skonfigurowaniu Twilio
      provider: "twilio",
    },
    push: {
      enabled: true,       // In-app notifications (działa od razu)
    },
  },

  /**
   * Reklamy - ile slotów
   */
  ads: {
    maxSlots: 25,
    allowHtml: true,       // HTML bannery z DOMPurify sanitization
    trackClicks: true,
  },

  /**
   * Opinie - moderacja
   */
  testimonials: {
    requireApproval: true, // Nowe opinie wymagają zatwierdzenia
    maxRating: 5,
  },

  /**
   * Motywy aplikacji
   */
  themes: {
    available: ["normal", "christmas", "new_year", "summer", "easter"],
    default: "normal",
  },

  /**
   * Pagination - ile elementów na stronę
   */
  pagination: {
    users: 50,
    transactions: 20,
    messages: 30,
    ads: 25,
    testimonials: 20,
  },

  /**
   * Dev mode - bypass dla developmentu
   */
  dev: {
    bypassAuth: process.env.NODE_ENV === "development",
    showDebugInfo: process.env.NODE_ENV === "development",
  },
};

/**
 * Helper function - sprawdź czy feature jest włączone
 */
export function isFeatureEnabled(featureName: keyof typeof adminConfig.features): boolean {
  return adminConfig.features[featureName] ?? false;
}

/**
 * Helper function - sprawdź czy user ma daną rolę
 */
export function hasRole(userRole: string, requiredRole: string): boolean {
  const roleHierarchy = {
    ADMIN: 3,
    EDITOR: 2,
    USER: 1,
  };
  
  return (roleHierarchy[userRole as keyof typeof roleHierarchy] ?? 0) >= 
         (roleHierarchy[requiredRole as keyof typeof roleHierarchy] ?? 0);
}
