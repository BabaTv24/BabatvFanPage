import { useQuery, useMutation } from "@tanstack/react-query";
import { Shield, ShieldCheck, Calendar, UserPlus, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { pl } from "date-fns/locale";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, Entitlement } from "@shared/schema";
import { EditUserDialog } from "@/components/edit-user-dialog";
import { AddUserDialog } from "@/components/add-user-dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface UserWithEntitlement extends User {
  entitlement?: Entitlement | null;
}

export default function AdminUsers() {
  const { toast } = useToast();
  const { data: users, isLoading } = useQuery<UserWithEntitlement[]>({
    queryKey: ["/api/admin/users"],
  });

  const grantAccessMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/grant-access`, {});
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Sukces!",
        description: data.message || "Dostęp został przyznany",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się przyznać dostępu",
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      await apiRequest("DELETE", `/api/admin/users/${userId}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Sukces!",
        description: "Użytkownik został usunięty",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się usunąć użytkownika",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return <div className="text-muted-foreground">Ładowanie...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-heading mb-2">Użytkownicy</h1>
          <p className="text-muted-foreground">
            Zarządzaj użytkownikami i ich dostępem
          </p>
        </div>
        <AddUserDialog />
      </div>

      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-20">ID</TableHead>
                <TableHead>Email</TableHead>
                <TableHead className="hidden sm:table-cell">Rola</TableHead>
                <TableHead>Status dostępu</TableHead>
                <TableHead className="hidden lg:table-cell">Data wygaśnięcia</TableHead>
                <TableHead className="hidden xl:table-cell">Data rejestracji</TableHead>
                <TableHead className="text-right whitespace-nowrap">Akcje</TableHead>
              </TableRow>
            </TableHeader>
          <TableBody>
            {users?.map((user) => {
              const hasAccess = user.entitlement && new Date(user.entitlement.expiresAt) > new Date();
              
              return (
                <TableRow key={user.id} data-testid={`user-row-${user.email}`}>
                  <TableCell className="font-mono font-bold text-primary text-sm">
                    {user.userId}
                  </TableCell>
                  <TableCell className="font-medium text-sm">{user.email}</TableCell>
                  <TableCell className="hidden sm:table-cell">
                    <Badge variant={user.role === "ADMIN" ? "default" : "secondary"}>
                      {user.role === "ADMIN" ? (
                        <ShieldCheck className="w-3 h-3 mr-1" />
                      ) : (
                        <Shield className="w-3 h-3 mr-1" />
                      )}
                      {user.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={hasAccess ? "default" : "secondary"}>
                      {hasAccess ? "Aktywny" : "Nieaktywny"}
                    </Badge>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell">
                    {user.entitlement ? (
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        {format(new Date(user.entitlement.expiresAt), "dd MMM yyyy", { locale: pl })}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm hidden xl:table-cell">
                    {format(new Date(user.createdAt), "dd MMM yyyy", { locale: pl })}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <EditUserDialog user={user} />
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => grantAccessMutation.mutate(user.userId)}
                            disabled={grantAccessMutation.isPending}
                            data-testid={`button-grant-access-${user.userId}`}
                          >
                            <UserPlus className="w-4 h-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Przyznaj 30 dni dostępu</p>
                        </TooltipContent>
                      </Tooltip>
                      <AlertDialog>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <AlertDialogTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                disabled={deleteUserMutation.isPending}
                                data-testid={`button-delete-${user.userId}`}
                              >
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </AlertDialogTrigger>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Usuń użytkownika</p>
                          </TooltipContent>
                        </Tooltip>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Czy na pewno chcesz usunąć tego użytkownika?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Ta operacja jest nieodwracalna. Użytkownik <strong>{user.email}</strong> (ID: {user.userId}) 
                              zostanie usunięty wraz ze wszystkimi powiązanymi danymi (dostęp, transakcje, powiadomienia).
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel data-testid={`button-cancel-delete-${user.userId}`}>
                              Anuluj
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => deleteUserMutation.mutate(user.userId)}
                              data-testid={`button-confirm-delete-${user.userId}`}
                              className="bg-destructive hover:bg-destructive/90"
                            >
                              Usuń
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
