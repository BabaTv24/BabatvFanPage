import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Trash2, Eye, EyeOff, Edit, Plus } from "lucide-react";
import { SiTelegram, SiFacebook, SiInstagram, SiYoutube, SiDiscord, SiWhatsapp, SiTiktok, SiLinkedin, SiSnapchat, SiReddit } from "react-icons/si";
import { FaXTwitter } from "react-icons/fa6";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertSocialMediaLinkSchema, type SocialMediaLink } from "@shared/schema";

const platformIcons: Record<string, any> = {
  telegram: SiTelegram,
  facebook: SiFacebook,
  instagram: SiInstagram,
  youtube: SiYoutube,
  discord: SiDiscord,
  x: FaXTwitter,
  whatsapp: SiWhatsapp,
  tiktok: SiTiktok,
  linkedin: SiLinkedin,
  snapchat: SiSnapchat,
  reddit: SiReddit,
};

const platformColors: Record<string, string> = {
  telegram: "#0088cc",
  facebook: "#1877f2",
  instagram: "#e4405f",
  youtube: "#ff0000",
  discord: "#5865f2",
  x: "#000000",
  whatsapp: "#25D366",
  tiktok: "#000000",
  linkedin: "#0077b5",
  snapchat: "#FFFC00",
  reddit: "#FF4500",
};

const iconMap: Record<string, string> = {
  telegram: "SiTelegram",
  facebook: "SiFacebook",
  instagram: "SiInstagram",
  youtube: "SiYoutube",
  discord: "SiDiscord",
  x: "FaXTwitter",
  whatsapp: "SiWhatsapp",
  tiktok: "SiTiktok",
  linkedin: "SiLinkedin",
  snapchat: "SiSnapchat",
  reddit: "SiReddit",
};

type FormValues = z.infer<typeof insertSocialMediaLinkSchema>;

export default function AdminSocialMedia() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingLink, setEditingLink] = useState<SocialMediaLink | null>(null);

  const { data: socialMediaLinks, isLoading } = useQuery<SocialMediaLink[]>({
    queryKey: ["/api/admin/social-media-links"],
  });

  const [selectedPlatform, setSelectedPlatform] = useState("");

  const form = useForm<FormValues>({
    resolver: zodResolver(insertSocialMediaLinkSchema),
    defaultValues: {
      platform: "",
      url: "",
      icon: "",
      order: 1,
      enabled: true,
    },
  });

  useEffect(() => {
    if (editingLink) {
      form.reset({
        platform: editingLink.platform,
        url: editingLink.url,
        icon: editingLink.icon,
        order: editingLink.order,
        enabled: editingLink.enabled,
      });
      setSelectedPlatform(editingLink.platform);
    } else if (dialogOpen) {
      form.reset({
        platform: "",
        url: "",
        icon: "",
        order: (socialMediaLinks?.length || 0) + 1,
        enabled: true,
      });
      setSelectedPlatform("");
    }
  }, [editingLink, dialogOpen, socialMediaLinks, form]);

  const createMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      return apiRequest("POST", "/api/admin/social-media-links", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/social-media-links"] });
      toast({
        title: "Dodano",
        description: "Link social media został dodany",
      });
      setDialogOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się dodać linku",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      if (!editingLink) return;
      return apiRequest("PATCH", `/api/admin/social-media-links/${editingLink.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/social-media-links"] });
      toast({
        title: "Zaktualizowano",
        description: "Link social media został zaktualizowany",
      });
      setDialogOpen(false);
      setEditingLink(null);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować linku",
        variant: "destructive",
      });
    },
  });

  const toggleEnabledMutation = useMutation({
    mutationFn: async ({ id, enabled }: { id: string; enabled: boolean }) => {
      return apiRequest("PATCH", `/api/admin/social-media-links/${id}`, { enabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/social-media-links"] });
      toast({
        title: "Zaktualizowano",
        description: "Status linku został zmieniony",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/admin/social-media-links/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/social-media-links"] });
      toast({
        title: "Usunięto",
        description: "Link social media został usunięty",
      });
    },
  });

  const handleEdit = (link: SocialMediaLink) => {
    setEditingLink(link);
    setDialogOpen(true);
  };

  const handleSubmit = (data: FormValues) => {
    if (editingLink) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const handlePlatformChange = (platform: string) => {
    setSelectedPlatform(platform);
    form.setValue("platform", platform); // Preserve original casing for display
    
    // Auto-fill icon if it's a predefined platform (use lowercase for lookup only)
    const icon = iconMap[platform.toLowerCase()];
    if (icon) {
      form.setValue("icon", icon);
    }
  };

  if (isLoading) {
    return <div className="text-muted-foreground">Ładowanie...</div>;
  }

  const sortedLinks = [...(socialMediaLinks || [])].sort((a, b) => a.order - b.order);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading mb-2">Social Media Bar</h1>
          <p className="text-muted-foreground">
            Zarządzaj linkami do social media wyświetlanymi u góry strony
          </p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) {
            setEditingLink(null);
            form.reset();
          }
        }}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-link">
              <Plus className="w-4 h-4 mr-2" />
              Dodaj link
            </Button>
          </DialogTrigger>
          <DialogContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)}>
                <DialogHeader>
                  <DialogTitle>{editingLink ? "Edytuj link" : "Dodaj nowy link"}</DialogTitle>
                  <DialogDescription>
                    Skonfiguruj link do social media
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <FormField
                    control={form.control}
                    name="platform"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Platforma</FormLabel>
                        <Select
                          onValueChange={(value) => {
                            field.onChange(value);
                            handlePlatformChange(value);
                          }}
                          value={selectedPlatform || field.value}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-platform">
                              <SelectValue placeholder="Wybierz platformę" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Telegram">Telegram</SelectItem>
                            <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                            <SelectItem value="X">X (Twitter)</SelectItem>
                            <SelectItem value="YouTube">YouTube</SelectItem>
                            <SelectItem value="Discord">Discord</SelectItem>
                            <SelectItem value="Facebook">Facebook</SelectItem>
                            <SelectItem value="Instagram">Instagram</SelectItem>
                            <SelectItem value="TikTok">TikTok</SelectItem>
                            <SelectItem value="LinkedIn">LinkedIn</SelectItem>
                            <SelectItem value="Snapchat">Snapchat</SelectItem>
                            <SelectItem value="Reddit">Reddit</SelectItem>
                            <SelectItem value="custom">Własna platforma...</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground mt-1">
                          Wybierz z listy lub wpisz własną nazwę poniżej
                        </p>
                        <FormControl>
                          <Input
                            type="text"
                            placeholder="Lub wpisz własną nazwę platformy..."
                            data-testid="input-platform-custom"
                            value={field.value}
                            onChange={(e) => {
                              field.onChange(e.target.value);
                              handlePlatformChange(e.target.value);
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="icon"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ikona (react-icons)</FormLabel>
                        <FormControl>
                          <Input
                            type="text"
                            placeholder="np. SiWhatsapp, SiTelegram, SiLinkedin..."
                            data-testid="input-icon"
                            {...field}
                          />
                        </FormControl>
                        <p className="text-xs text-muted-foreground">
                          Nazwa ikony z react-icons (SiX dla Simple Icons, FaX dla Font Awesome)
                        </p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="url"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>URL</FormLabel>
                        <FormControl>
                          <Input
                            type="url"
                            placeholder="https://..."
                            data-testid="input-url"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="order"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Kolejność</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            data-testid="input-order"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <DialogFooter>
                  <Button type="submit" data-testid="button-submit" disabled={createMutation.isPending || updateMutation.isPending}>
                    {editingLink ? "Zaktualizuj" : "Dodaj"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-20">Kolejność</TableHead>
                <TableHead>Platforma</TableHead>
                <TableHead>URL</TableHead>
                <TableHead className="w-24">Status</TableHead>
                <TableHead className="w-32 text-right">Akcje</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedLinks.map((link) => {
                const IconComponent = platformIcons[link.platform.toLowerCase()];
                const color = platformColors[link.platform.toLowerCase()];
                
                return (
                  <TableRow key={link.id} data-testid={`link-row-${link.platform}`}>
                    <TableCell className="font-medium">#{link.order}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {IconComponent && (
                          <IconComponent
                            className="w-5 h-5"
                            style={{ color }}
                          />
                        )}
                        <span>{link.platform}</span>
                      </div>
                    </TableCell>
                    <TableCell className="max-w-xs truncate">
                      <a
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        {link.url}
                      </a>
                    </TableCell>
                    <TableCell>
                      <Badge variant={link.enabled ? "default" : "secondary"}>
                        {link.enabled ? "Aktywny" : "Nieaktywny"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => toggleEnabledMutation.mutate({ id: link.id, enabled: !link.enabled })}
                              data-testid={`button-toggle-${link.platform}`}
                            >
                              {link.enabled ? (
                                <EyeOff className="w-4 h-4" />
                              ) : (
                                <Eye className="w-4 h-4" />
                              )}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            {link.enabled ? "Dezaktywuj" : "Aktywuj"}
                          </TooltipContent>
                        </Tooltip>
                        
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(link)}
                              data-testid={`button-edit-${link.platform}`}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Edytuj link</TooltipContent>
                        </Tooltip>
                        
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteMutation.mutate(link.id)}
                              data-testid={`button-delete-${link.platform}`}
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Usuń link</TooltipContent>
                        </Tooltip>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
              
              {sortedLinks.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    Brak linków. Dodaj pierwszy link używając przycisku "Dodaj link".
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
