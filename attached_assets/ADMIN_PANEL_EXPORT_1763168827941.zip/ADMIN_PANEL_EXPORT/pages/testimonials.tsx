import { useQuery } from "@tanstack/react-query";
import { Edit, Trash2, Eye, EyeOff, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { AddTestimonialDialog } from "@/components/add-testimonial-dialog";
import type { Testimonial } from "@shared/schema";

export default function AdminTestimonials() {
  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ["/api/admin/testimonials"],
  });

  if (isLoading) {
    return <div className="text-muted-foreground">Ładowanie...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading mb-2">Opinie klientów</h1>
          <p className="text-muted-foreground">
            Zarządzaj opiniami wyświetlanymi na stronie głównej
          </p>
        </div>
        <AddTestimonialDialog />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {testimonials?.map((testimonial) => (
          <Card key={testimonial.id} className="p-6" data-testid={`testimonial-card-${testimonial.id}`}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={testimonial.avatarUrl} />
                  <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">{testimonial.name}</h3>
                  <div className="flex gap-0.5 mt-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < testimonial.rating
                            ? "fill-primary text-primary"
                            : "fill-muted text-muted"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
              <Badge variant={testimonial.active ? "default" : "secondary"}>
                {testimonial.active ? "Aktywna" : "Nieaktywna"}
              </Badge>
            </div>

            <p className="text-sm text-muted-foreground mb-4 italic">
              "{testimonial.quote}"
            </p>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="flex-1">
                <Edit className="w-3 h-3 mr-1" />
                Edytuj
              </Button>
              <Button variant="ghost" size="icon">
                {testimonial.active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
              <Button variant="ghost" size="icon">
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
