import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Mail, MessageSquare, Send, Clock, CheckCircle2, XCircle, Bell, Globe } from "lucide-react";
import type { MessageLog } from "@shared/schema";

// Form validation schema
const messageFormSchema = z.object({
  type: z.enum(['EMAIL', 'SMS', 'PUSH', 'GLOBAL']),
  subject: z.string().optional(),
  message: z.string().min(1, "Treść wiadomości jest wymagana").max(500, "Wiadomość może mieć maksymalnie 500 znaków"),
  recipientFilter: z.enum(['all', 'active', 'expired']),
}).refine(
  (data) => data.type !== 'EMAIL' || (data.subject && data.subject.length > 0),
  {
    message: "Temat jest wymagany dla wiadomości email",
    path: ["subject"],
  }
);

type MessageFormData = z.infer<typeof messageFormSchema>;

export default function AdminMessages() {
  const { toast } = useToast();
  const [messageType, setMessageType] = useState<'EMAIL' | 'SMS' | 'PUSH' | 'GLOBAL'>('EMAIL');

  // Fetch message logs
  const { data: logsData, isLoading: logsLoading } = useQuery<{ logs: MessageLog[] }>({
    queryKey: ["/api/admin/messages/logs"],
  });

  const logs = logsData?.logs || [];

  // Form with zodResolver
  const form = useForm<MessageFormData>({
    resolver: zodResolver(messageFormSchema),
    defaultValues: {
      type: 'EMAIL',
      subject: '',
      message: '',
      recipientFilter: 'all',
    },
  });

  // Watch type field to show/hide subject field
  const watchType = form.watch('type');

  // Mutation for sending message
  const sendMessageMutation = useMutation({
    mutationFn: async (data: MessageFormData) => {
      // GLOBAL notifications use global endpoint (no recipient filter)
      if (data.type === 'GLOBAL') {
        const response = await apiRequest("POST", "/api/admin/global-notifications", {
          message: data.message,
        });
        return await response.json();
      }
      
      // PUSH notifications use different endpoint
      if (data.type === 'PUSH') {
        const response = await apiRequest("POST", "/api/admin/notifications/send", {
          message: data.message,
          recipientFilter: data.recipientFilter,
        });
        return await response.json();
      }
      
      // EMAIL and SMS use original endpoint
      const response = await apiRequest("POST", "/api/admin/messages/send", data);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Wiadomość wysłana",
        description: data.message || `Wysłano do ${data.successCount} z ${data.recipientsProcessed} odbiorców.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/messages/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/global-notifications"] });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Błąd wysyłania",
        description: error.message || "Nie udało się wysłać wiadomości.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MessageFormData) => {
    // Zod schema handles all validation including email subject requirement
    sendMessageMutation.mutate(data);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-green-500" data-testid="icon-status-completed" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" data-testid="icon-status-failed" />;
      case 'sending':
        return <Clock className="w-4 h-4 text-blue-500 animate-spin" data-testid="icon-status-sending" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" data-testid="icon-status-pending" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Wysłano';
      case 'failed':
        return 'Błąd';
      case 'sending':
        return 'Wysyłanie...';
      default:
        return 'Oczekuje';
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-messages">Wiadomości masowe</h1>
        <p className="text-muted-foreground" data-testid="text-description">
          Wysyłaj wiadomości email i SMS do wszystkich użytkowników
        </p>
      </div>

      {/* Send Message Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Wyślij wiadomość
          </CardTitle>
          <CardDescription>
            Wybierz typ wiadomości i wpisz treść
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {/* Message Type */}
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Typ wiadomości</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value);
                        setMessageType(value as 'EMAIL' | 'SMS' | 'PUSH' | 'GLOBAL');
                      }}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-message-type">
                          <SelectValue placeholder="Wybierz typ" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="EMAIL" data-testid="option-email">
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4" />
                            Email
                          </div>
                        </SelectItem>
                        <SelectItem value="SMS" data-testid="option-sms">
                          <div className="flex items-center gap-2">
                            <MessageSquare className="w-4 h-4" />
                            SMS
                          </div>
                        </SelectItem>
                        <SelectItem value="PUSH" data-testid="option-push">
                          <div className="flex items-center gap-2">
                            <Bell className="w-4 h-4" />
                            Powiadomienie Push
                          </div>
                        </SelectItem>
                        <SelectItem value="GLOBAL" data-testid="option-global">
                          <div className="flex items-center gap-2">
                            <Globe className="w-4 h-4" />
                            Powiadomienie Globalne
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      {watchType === 'EMAIL' 
                        ? 'Email zostanie wysłany do wybranych użytkowników'
                        : watchType === 'SMS'
                        ? 'SMS zostanie wysłany do wybranych użytkowników z numerem telefonu'
                        : watchType === 'PUSH'
                        ? 'Powiadomienie pojawi się w aplikacji dla zalogowanych użytkowników'
                        : 'Powiadomienie globalne widoczne dla WSZYSTKICH użytkowników (zalogowanych i anonimowych)'}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Recipient Filter (not for GLOBAL) */}
              {watchType !== 'GLOBAL' && (
                <FormField
                  control={form.control}
                  name="recipientFilter"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Odbiorcy</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-recipient-filter">
                            <SelectValue placeholder="Wybierz grupę odbiorców" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="all" data-testid="option-all">
                            Wszyscy użytkownicy
                          </SelectItem>
                          <SelectItem value="active" data-testid="option-active">
                            Tylko z aktywnym dostępem
                          </SelectItem>
                          <SelectItem value="expired" data-testid="option-expired">
                            Tylko z wygasłym dostępem
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Wybierz do której grupy użytkowników wysłać wiadomość
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* Subject (Email only) */}
              {watchType === 'EMAIL' && (
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Temat</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Ważna informacja od BABATV24" 
                          {...field} 
                          data-testid="input-subject"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* Message Content */}
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Treść wiadomości</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={
                          watchType === 'EMAIL'
                            ? 'Witaj! Mamy dla Ciebie ważną wiadomość...'
                            : 'BABATV24: Twoja wiadomość (max 160 znaków)'
                        }
                        className="min-h-[150px]"
                        {...field}
                        data-testid="textarea-message"
                      />
                    </FormControl>
                    <FormDescription>
                      {watchType === 'SMS' && 'SMS powinien być krótki (max 160 znaków)'}
                      {field.value && (
                        <span className="ml-2">
                          {field.value.length}/1000 znaków
                        </span>
                      )}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                disabled={sendMessageMutation.isPending}
                className="w-full sm:w-auto"
                data-testid="button-send-message"
              >
                {sendMessageMutation.isPending ? (
                  <>
                    <Clock className="w-4 h-4 mr-2 animate-spin" />
                    Wysyłanie...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Wyślij wiadomość
                  </>
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Message History */}
      <Card>
        <CardHeader>
          <CardTitle>Historia wiadomości</CardTitle>
          <CardDescription>
            Ostatnio wysłane wiadomości do użytkowników
          </CardDescription>
        </CardHeader>
        <CardContent>
          {logsLoading ? (
            <div className="text-center py-8 text-muted-foreground" data-testid="text-loading">
              Ładowanie historii...
            </div>
          ) : !logs || logs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground" data-testid="text-no-messages">
              Nie wysłano jeszcze żadnych wiadomości
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="table-message-logs">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Status</th>
                    <th className="text-left p-2">Typ</th>
                    <th className="text-left p-2 hidden md:table-cell">Temat</th>
                    <th className="text-left p-2">Wiadomość</th>
                    <th className="text-left p-2 hidden sm:table-cell">Odbiorcy</th>
                    <th className="text-left p-2 hidden md:table-cell">Wysłał</th>
                    <th className="text-left p-2 hidden sm:table-cell">Data</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id} className="border-b" data-testid={`row-log-${log.id}`}>
                      <td className="p-2">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(log.status)}
                          <span className="text-sm">{getStatusText(log.status)}</span>
                        </div>
                      </td>
                      <td className="p-2">
                        <div className="flex items-center gap-2">
                          {log.type === 'email' ? (
                            <Mail className="w-4 h-4 text-blue-500" />
                          ) : log.type === 'sms' ? (
                            <MessageSquare className="w-4 h-4 text-green-500" />
                          ) : log.type === 'global' ? (
                            <Globe className="w-4 h-4 text-amber-500" />
                          ) : (
                            <Bell className="w-4 h-4 text-purple-500" />
                          )}
                          <span className="text-sm">
                            {log.type === 'email' ? 'Email' : 
                             log.type === 'sms' ? 'SMS' : 
                             log.type === 'global' ? 'Globalne' : 
                             'Push'}
                          </span>
                        </div>
                      </td>
                      <td className="p-2 max-w-[200px] truncate hidden md:table-cell" data-testid={`text-subject-${log.id}`}>
                        {log.subject || '-'}
                      </td>
                      <td className="p-2 max-w-[250px] sm:max-w-[300px] truncate" data-testid={`text-message-${log.id}`}>
                        {log.message}
                      </td>
                      <td className="p-2 hidden sm:table-cell" data-testid={`text-recipients-${log.id}`}>
                        {log.successCount}/{log.recipientCount}
                      </td>
                      <td className="p-2 text-sm text-muted-foreground hidden md:table-cell" data-testid={`text-sentby-${log.id}`}>
                        {log.sentBy}
                      </td>
                      <td className="p-2 text-sm text-muted-foreground hidden sm:table-cell" data-testid={`text-date-${log.id}`}>
                        {new Date(log.createdAt).toLocaleString('pl-PL')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
