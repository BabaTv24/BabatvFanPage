import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Euro, Users, TrendingUp, Clock, RefreshCw } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DashboardStats {
  totalRevenue: number;
  totalUsers: number;
  activeUsers: number;
  transactionsToday: number;
  revenueData: { date: string; amount: number }[];
  userGrowth: { date: string; count: number }[];
}

export default function AdminDashboard() {
  const { toast } = useToast();
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/stats"],
  });

  const syncCounterMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/admin/sync-counter", {});
    },
    onSuccess: (data: any) => {
      toast({
        title: "Sukces!",
        description: data.message || `Counter zaktualizowany: ${data.count} użytkowników`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/counter"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zsynchronizować countera",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-muted-foreground">Ładowanie statystyk...</div>
      </div>
    );
  }

  const kpiCards = [
    {
      title: "Całkowity przychód",
      value: `€${(stats?.totalRevenue || 0).toFixed(2)}`,
      icon: Euro,
      description: "Suma wszystkich płatności",
      color: "text-green-600",
    },
    {
      title: "Użytkownicy",
      value: stats?.totalUsers || 0,
      icon: Users,
      description: "Łączna liczba użytkowników",
      color: "text-blue-600",
    },
    {
      title: "Aktywni użytkownicy",
      value: stats?.activeUsers || 0,
      icon: TrendingUp,
      description: "Z ważnym dostępem",
      color: "text-primary",
    },
    {
      title: "Transakcje dziś",
      value: stats?.transactionsToday || 0,
      icon: Clock,
      description: "Płatności w ostatnich 24h",
      color: "text-purple-600",
    },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-heading mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Przegląd kluczowych wskaźników wydajności
          </p>
        </div>
        <Button
          onClick={() => syncCounterMutation.mutate()}
          disabled={syncCounterMutation.isPending}
          variant="default"
          data-testid="button-sync-counter"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${syncCounterMutation.isPending ? 'animate-spin' : ''}`} />
          {syncCounterMutation.isPending ? "Synchronizacja..." : "Aktualizuj App"}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiCards.map((card) => (
          <Card key={card.title} className="hover-elevate transition-all" data-testid={`kpi-${card.title}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {card.title}
              </CardTitle>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{card.value}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {card.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Przychody (ostatnie 7 dni)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats?.revenueData || []}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                  }}
                />
                <Bar dataKey="amount" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Wzrost użytkowników</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={stats?.userGrowth || []}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="count"
                  stroke="hsl(var(--accent))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--accent))" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
