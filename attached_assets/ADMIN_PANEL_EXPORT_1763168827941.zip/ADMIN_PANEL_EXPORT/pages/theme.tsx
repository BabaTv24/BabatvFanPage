import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { themeConfigSchema, type ThemeConfig } from "@shared/schema";
import { Palette, Sparkles, Sun, Snowflake, Egg } from "lucide-react";

const themeIcons = {
  normal: Sun,
  christmas: Snowflake,
  new_year: Sparkles,
  summer: Sun,
  easter: Egg,
};

const themeLabels = {
  normal: "Normalny",
  christmas: "Świąteczny (Boże Narodzenie)",
  new_year: "Noworoczny",
  summer: "Letni",
  easter: "Wielkanocny",
};

export default function AdminTheme() {
  const { toast } = useToast();

  // Fetch current theme config
  const { data: themeConfig, isLoading } = useQuery<ThemeConfig>({
    queryKey: ["/api/admin/theme"],
  });

  // Form with zodResolver
  const form = useForm<ThemeConfig>({
    resolver: zodResolver(themeConfigSchema),
    defaultValues: {
      theme: "normal",
      heroText: "Oglądaj premium treści przez 30 dni za jedyne €0.99",
      ctaText: "Aktywuj dostęp teraz",
    },
  });

  // Update form when data loads (inside useEffect to prevent infinite loop)
  useEffect(() => {
    if (themeConfig && !form.formState.isDirty) {
      form.reset(themeConfig);
    }
  }, [themeConfig, form]);

  // Mutation for updating theme
  const updateThemeMutation = useMutation<ThemeConfig, Error, ThemeConfig>({
    mutationFn: async (data: ThemeConfig) => {
      const response = await apiRequest("PUT", "/api/admin/theme", data);
      return await response.json();
    },
    onSuccess: async (data: ThemeConfig) => {
      // Force immediate refetch of both queries to propagate changes instantly
      await Promise.all([
        queryClient.refetchQueries({ queryKey: ["/api/admin/theme"] }),
        queryClient.refetchQueries({ queryKey: ["/api/theme"] }),
      ]);
      // Reset form to clear dirty state after successful save
      form.reset(data);
      toast({
        title: "Sukces!",
        description: "Wygląd aplikacji został zaktualizowany",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować wyglądu",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ThemeConfig) => {
    updateThemeMutation.mutate(data);
  };

  const selectedTheme = form.watch("theme");
  const ThemeIcon = themeIcons[selectedTheme] || Sun;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10">
          <Palette className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-heading">Wygląd aplikacji</h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Zarządzaj motywem i tekstami wyświetlanymi użytkownikom
          </p>
        </div>
      </div>

      <Card className="p-4 sm:p-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-sm text-muted-foreground">Ładowanie...</p>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Theme Selection */}
              <FormField
                control={form.control}
                name="theme"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Motyw aplikacji</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-theme">
                          <SelectValue placeholder="Wybierz motyw">
                            <div className="flex items-center gap-2">
                              <ThemeIcon className="w-4 h-4 flex-shrink-0" />
                              <span className="truncate">{themeLabels[selectedTheme]}</span>
                            </div>
                          </SelectValue>
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {Object.entries(themeLabels).map(([value, label]) => {
                          const Icon = themeIcons[value as keyof typeof themeIcons];
                          return (
                            <SelectItem
                              key={value}
                              value={value}
                              data-testid={`option-theme-${value}`}
                            >
                              <div className="flex items-center gap-2">
                                <Icon className="w-4 h-4 flex-shrink-0" />
                                <span>{label}</span>
                              </div>
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Wybierz motyw odpowiedni do pory roku lub święta
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Hero Text */}
              <FormField
                control={form.control}
                name="heroText"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tekst główny (Hero)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Wpisz główny tekst wyświetlany na stronie"
                        rows={3}
                        maxLength={200}
                        data-testid="input-hero-text"
                        className="resize-none"
                      />
                    </FormControl>
                    <FormDescription>
                      Maksymalnie 200 znaków. Tekst wyświetlany jako główne hasło na stronie.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* CTA Text */}
              <FormField
                control={form.control}
                name="ctaText"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tekst przycisku (CTA)</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Wpisz tekst przycisku"
                        maxLength={50}
                        data-testid="input-cta-text"
                      />
                    </FormControl>
                    <FormDescription>
                      Maksymalnie 50 znaków. Tekst wyświetlany na głównym przycisku akcji.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Submit Button */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button
                  type="submit"
                  disabled={updateThemeMutation.isPending || !form.formState.isDirty}
                  className="w-full sm:w-auto"
                  data-testid="button-save-theme"
                >
                  {updateThemeMutation.isPending ? "Zapisywanie..." : "Zapisz zmiany"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => form.reset()}
                  disabled={!form.formState.isDirty}
                  className="w-full sm:w-auto"
                  data-testid="button-reset-theme"
                >
                  Anuluj
                </Button>
              </div>
            </form>
          </Form>
        )}
      </Card>
    </div>
  );
}
