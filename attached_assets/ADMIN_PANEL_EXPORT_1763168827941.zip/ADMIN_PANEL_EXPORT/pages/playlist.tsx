import { useQuery, useMutation } from "@tanstack/react-query";
import { GripVertical, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AddClipDialog } from "@/components/add-clip-dialog";
import { EditClipDialog } from "@/components/edit-clip-dialog";
import { DeleteClipDialog } from "@/components/delete-clip-dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Clip } from "@shared/schema";

export default function AdminPlaylist() {
  const { toast } = useToast();
  const { data: clips, isLoading } = useQuery<Clip[]>({
    queryKey: ["/api/admin/playlist"],
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const res = await apiRequest("PATCH", `/api/admin/playlist/${id}`, { active: !active });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Sukces!",
        description: "Status klipu został zmieniony",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/playlist"] });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zmienić statusu",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return <div className="text-muted-foreground">Ładowanie...</div>;
  }

  const sortedClips = [...(clips || [])].sort((a, b) => a.order - b.order);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading mb-2">Playlista</h1>
          <p className="text-muted-foreground">
            Zarządzaj kolejnością i statusem klipów wideo
          </p>
        </div>
        <AddClipDialog />
      </div>

      <Card className="p-6">
        <div className="space-y-2">
          {sortedClips.map((clip) => (
            <div
              key={clip.id}
              className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 p-3 sm:p-4 rounded-lg border border-border hover-elevate"
              data-testid={`clip-${clip.order}`}
            >
              <div className="flex items-center gap-3 sm:gap-4 w-full sm:w-auto">
                <button className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground hidden sm:block">
                  <GripVertical className="w-5 h-5" />
                </button>

                <div className="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-muted rounded-lg font-bold text-muted-foreground flex-shrink-0">
                  {clip.order}
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm sm:text-base">{clip.title}</h3>
                  <p className="text-xs sm:text-sm text-muted-foreground truncate">
                    {clip.url}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Długość: {clip.lengthSec}s
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-2 w-full sm:w-auto">
                <Badge variant={clip.active ? "default" : "secondary"}>
                  {clip.active ? "Aktywny" : "Nieaktywny"}
                </Badge>

                <div className="flex items-center gap-1 sm:gap-2">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => toggleActiveMutation.mutate({ id: clip.id, active: clip.active })}
                    disabled={toggleActiveMutation.isPending}
                    data-testid={`button-toggle-${clip.order}`}
                  >
                    {clip.active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                  <EditClipDialog clip={clip} />
                  <DeleteClipDialog clip={clip} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
