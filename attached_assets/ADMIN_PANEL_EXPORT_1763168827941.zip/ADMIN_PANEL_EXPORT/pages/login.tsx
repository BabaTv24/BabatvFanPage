import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Lock, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [password, setPassword] = useState("");
  const [returnUrl, setReturnUrl] = useState<string | null>(null);

  // Extract returnUrl from query parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const url = params.get("returnUrl");
    if (url) {
      setReturnUrl(decodeURIComponent(url));
    }
  }, []);

  const loginMutation = useMutation({
    mutationFn: async (password: string) => {
      const res = await apiRequest("POST", "/api/admin/login", { password });
      return res.json();
    },
    onSuccess: async () => {
      // Invalidate admin check query to refresh auth state
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/check"] });
      
      toast({
        title: "Zalogowano pomyślnie!",
        description: returnUrl 
          ? "Przekierowywanie do poprzedniej strony..." 
          : "Przekierowywanie do panelu administracyjnego...",
      });
      
      // Redirect to returnUrl if present, otherwise to /admin
      const destination = returnUrl || "/admin";
      window.location.href = destination;
    },
    onError: (error: any) => {
      toast({
        title: "Błąd logowania",
        description: error.message || "Nieprawidłowe hasło",
        variant: "destructive",
      });
      setPassword("");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      toast({
        title: "Błąd",
        description: "Proszę wprowadzić hasło",
        variant: "destructive",
      });
      return;
    }
    loginMutation.mutate(password);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold font-heading mb-2">Panel Administracyjny</h1>
          <p className="text-muted-foreground">
            Wprowadź hasło administratora aby kontynuować
          </p>
        </div>

        <Card className="p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="password" className="text-base font-semibold">
                Hasło administratora
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Wprowadź hasło"
                  className="pl-10 h-12 text-base"
                  autoFocus
                  disabled={loginMutation.isPending}
                  data-testid="input-admin-password"
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-12 text-base font-bold"
              disabled={loginMutation.isPending}
              data-testid="button-admin-login"
            >
              {loginMutation.isPending ? "Logowanie..." : "Zaloguj się"}
            </Button>
          </form>

          <div className="mt-6 p-4 bg-muted/50 rounded-lg">
            <p className="text-xs text-muted-foreground text-center">
              🔒 Sesja jest zabezpieczona. Hasło jest weryfikowane za pomocą bcrypt.
            </p>
          </div>
        </Card>

        <div className="mt-6 text-center">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            data-testid="button-back-home"
          >
            ← Powrót do strony głównej
          </Button>
        </div>
      </div>
    </div>
  );
}
