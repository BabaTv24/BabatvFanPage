import { Route, Switch, useLocation, Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Image,
  MessageSquare,
  Users,
  PlaySquare,
  Palette,
  Settings,
  LogOut,
  Mail,
  Share2,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import AdminGuard from "@/components/admin-guard";
import AdminDashboard from "./dashboard";
import AdminAds from "./ads";
import AdminTestimonials from "./testimonials";
import AdminUsers from "./users";
import AdminPlaylist from "./playlist";
import AdminTheme from "./theme";
import AdminMessages from "./messages";
import AdminSocialMedia from "./social-media";

const menuItems = [
  {
    title: "Dashboard",
    url: "/admin",
    icon: LayoutDashboard,
  },
  {
    title: "Sloty reklamowe",
    url: "/admin/ads",
    icon: Image,
  },
  {
    title: "Opinie klientów",
    url: "/admin/testimonials",
    icon: MessageSquare,
  },
  {
    title: "Social Media Bar",
    url: "/admin/social-media",
    icon: Share2,
  },
  {
    title: "Użytkownicy",
    url: "/admin/users",
    icon: Users,
  },
  {
    title: "Playlista",
    url: "/admin/playlist",
    icon: PlaySquare,
  },
  {
    title: "Wygląd aplikacji",
    url: "/admin/theme",
    icon: Palette,
  },
  {
    title: "Wiadomości",
    url: "/admin/messages",
    icon: Mail,
  },
];

function AdminSidebar() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/logout");
      return res.json();
    },
    onSuccess: () => {
      queryClient.clear();
      toast({
        title: "Wylogowano pomyślnie",
        description: "Do zobaczenia!",
      });
      setTimeout(() => {
        setLocation("/admin/login");
      }, 500);
    },
    onError: (error: any) => {
      toast({
        title: "Błąd wylogowania",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-lg font-heading text-primary mb-4">
            BABATV24 Admin
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <SidebarMenuButton
                        isActive={location === item.url}
                        onClick={() => setLocation(item.url)}
                        data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <item.icon />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </TooltipTrigger>
                    <TooltipContent side="right">{item.title}</TooltipContent>
                  </Tooltip>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-auto">
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <SidebarMenuButton onClick={() => setLocation("/")}>
                      <Settings />
                      <span>Strona główna</span>
                    </SidebarMenuButton>
                  </TooltipTrigger>
                  <TooltipContent side="right">Powrót do strony głównej</TooltipContent>
                </Tooltip>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <SidebarMenuButton 
                      onClick={() => logoutMutation.mutate()}
                      disabled={logoutMutation.isPending}
                      data-testid="button-logout"
                    >
                      <LogOut />
                      <span>{logoutMutation.isPending ? "Wylogowywanie..." : "Wyloguj"}</span>
                    </SidebarMenuButton>
                  </TooltipTrigger>
                  <TooltipContent side="right">Wyloguj z panelu administracyjnego</TooltipContent>
                </Tooltip>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}

export default function AdminLayout() {
  const style = {
    "--sidebar-width": "16rem",
  };

  return (
    <AdminGuard>
      <SidebarProvider style={style as React.CSSProperties}>
        <div className="flex h-screen w-full">
          <AdminSidebar />
          <div className="flex flex-col flex-1">
            <header className="flex items-center gap-2 border-b px-4 py-3 bg-background">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <h2 className="text-lg font-semibold">Panel Administracyjny</h2>
            </header>
            <main className="flex-1 overflow-auto p-8 bg-background">
              <Switch>
                <Route path="/admin" component={AdminDashboard} />
                <Route path="/admin/ads" component={AdminAds} />
                <Route path="/admin/testimonials" component={AdminTestimonials} />
                <Route path="/admin/social-media" component={AdminSocialMedia} />
                <Route path="/admin/users" component={AdminUsers} />
                <Route path="/admin/playlist" component={AdminPlaylist} />
                <Route path="/admin/theme" component={AdminTheme} />
                <Route path="/admin/messages" component={AdminMessages} />
                <Route component={AdminDashboard} />
              </Switch>
            </main>
          </div>
        </div>
      </SidebarProvider>
    </AdminGuard>
  );
}
