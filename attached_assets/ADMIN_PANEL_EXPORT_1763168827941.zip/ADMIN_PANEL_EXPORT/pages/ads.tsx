import { useQuery, useMutation } from "@tanstack/react-query";
import { Trash2, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AddAdDialog } from "@/components/add-ad-dialog";
import { EditAdDialog } from "@/components/edit-ad-dialog";
import type { AdSlot } from "@shared/schema";

export default function AdminAds() {
  const { toast } = useToast();

  const { data: adSlots, isLoading } = useQuery<AdSlot[]>({
    queryKey: ["/api/admin/ads"],
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      return apiRequest("PATCH", `/api/admin/ads/${id}`, { active });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ads"] });
      toast({
        title: "Zaktualizowano",
        description: "Status reklamy został zmieniony",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/admin/ads/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ads"] });
      toast({
        title: "Usunięto",
        description: "Reklama została usunięta",
      });
    },
  });

  if (isLoading) {
    return <div className="text-muted-foreground">Ładowanie...</div>;
  }

  const sortedSlots = [...(adSlots || [])].sort((a, b) => a.position - b.position);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading mb-2">Sloty reklamowe</h1>
          <p className="text-muted-foreground">
            Zarządzaj 25 slotami w pasku reklamowym
          </p>
        </div>
        <AddAdDialog />
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table className="min-w-[600px] md:min-w-0">
            <TableHeader>
              <TableRow>
                <TableHead className="w-20">Pozycja</TableHead>
                <TableHead>Logo</TableHead>
                <TableHead>Tytuł</TableHead>
                <TableHead className="hidden md:table-cell">Tekst</TableHead>
                <TableHead className="w-24">Kliknięcia</TableHead>
                <TableHead className="w-24">Status</TableHead>
                <TableHead className="w-32 text-right">Akcje</TableHead>
              </TableRow>
            </TableHeader>
          <TableBody>
            {sortedSlots.map((slot) => (
              <TableRow key={slot.id} data-testid={`ad-row-${slot.position}`}>
                <TableCell className="font-medium">#{slot.position}</TableCell>
                <TableCell>
                  {slot.logoUrl ? (
                    <img
                      src={slot.logoUrl}
                      alt={slot.title}
                      className="w-10 h-10 object-contain rounded"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded bg-muted flex items-center justify-center text-xs text-muted-foreground">
                      HTML
                    </div>
                  )}
                </TableCell>
                <TableCell className="font-medium">{slot.title}</TableCell>
                <TableCell className="text-muted-foreground max-w-xs truncate hidden md:table-cell">
                  {slot.text}
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{slot.clicks}</Badge>
                </TableCell>
                <TableCell>
                  <Badge variant={slot.active ? "default" : "secondary"}>
                    {slot.active ? "Aktywna" : "Nieaktywna"}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleActiveMutation.mutate({ id: slot.id, active: !slot.active })}
                          data-testid={`button-toggle-${slot.position}`}
                        >
                          {slot.active ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        {slot.active ? "Dezaktywuj reklamę" : "Aktywuj reklamę"}
                      </TooltipContent>
                    </Tooltip>
                    
                    <EditAdDialog ad={slot} />
                    
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteMutation.mutate(slot.id)}
                          data-testid={`button-delete-${slot.position}`}
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Usuń reklamę</TooltipContent>
                    </Tooltip>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
