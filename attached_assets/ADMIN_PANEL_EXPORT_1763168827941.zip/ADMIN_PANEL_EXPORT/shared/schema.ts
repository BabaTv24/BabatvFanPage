import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - magic link authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: integer("user_id").notNull().unique().default(sql`nextval('user_id_seq')`), // 7-digit unique number (auto-generated from 1000000)
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("USER"), // USER | ADMIN | EDITOR
  firstName: text("first_name"),
  lastName: text("last_name"),
  avatarUrl: text("avatar_url"),
  phone: text("phone"),
  address: text("address"),
  city: text("city"),
  country: text("country"),
  postalCode: text("postal_code"),
  bankName: text("bank_name"),
  bankAccountNumber: text("bank_account_number"),
  bankIban: text("bank_iban"),
  bankSwift: text("bank_swift"),
  socialFacebook: text("social_facebook"),
  socialInstagram: text("social_instagram"),
  socialX: text("social_x"),
  socialTiktok: text("social_tiktok"),
  socialYoutube: text("social_youtube"),
  socialLinkedin: text("social_linkedin"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const usersRelations = relations(users, ({ one, many }) => ({
  entitlement: one(entitlements),
  transactions: many(transactions),
}));

// Entitlements table - 30-day access passes
export const entitlements = pgTable("entitlements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique().references(() => users.id),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const entitlementsRelations = relations(entitlements, ({ one }) => ({
  user: one(users, {
    fields: [entitlements.userId],
    references: [users.id],
  }),
}));

// Transactions table - payment records
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  amount: integer("amount").notNull(), // in cents
  currency: text("currency").notNull().default("EUR"),
  provider: text("provider").notNull(), // stripe | paypal | crypto
  providerId: text("provider_id").notNull(), // transaction id from provider
  status: text("status").notNull().default("pending"), // pending | paid | failed | refunded
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

// Ad Slots table - 25 slots for header ticker
export const adSlots = pgTable("ad_slots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  position: integer("position").notNull().unique(), // 1-25
  active: boolean("active").notNull().default(true),
  title: text("title").notNull(),
  text: text("text").notNull(),
  url: text("url").notNull(),
  logoUrl: text("logo_url"), // Optional if using htmlContent
  htmlContent: text("html_content"), // Optional HTML banner (alternative to image)
  clicks: integer("clicks").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Testimonials table - customer reviews
export const testimonials = pgTable("testimonials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  avatarUrl: text("avatar_url").notNull(),
  rating: integer("rating").notNull(), // 1-5
  quote: text("quote").notNull(), // max 120 chars
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Clips table - video playlist items
export const clips = pgTable("clips", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  url: text("url").notNull(), // HLS or MP4 URL
  lengthSec: integer("length_sec").notNull(), // typically 45
  order: integer("order").notNull().unique(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// App Settings table - global configuration
export const appSettings = pgTable("app_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Message Logs table - history of sent messages
export const messageLogs = pgTable("message_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // 'email' or 'sms'
  subject: text("subject"), // For emails
  message: text("message").notNull(),
  recipientCount: integer("recipient_count").notNull(),
  successCount: integer("success_count").notNull().default(0),
  failureCount: integer("failure_count").notNull().default(0),
  status: text("status").notNull(), // 'pending', 'sending', 'completed', 'failed'
  sentBy: text("sent_by").notNull(), // Admin email who sent the message
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Notifications table - in-app push notifications
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

// Global Notifications table - public announcements visible to everyone
export const globalNotifications = pgTable("global_notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Social Media Links table - configurable social media bar
export const socialMediaLinks = pgTable("social_media_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  platform: text("platform").notNull(), // telegram, x, youtube, discord, facebook, instagram
  url: text("url").notNull(),
  icon: text("icon").notNull(), // react-icons/si icon name (e.g., 'SiTelegram')
  order: integer("order").notNull().unique(),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  userId: true, // Auto-generated from user_id_seq
  createdAt: true,
}).extend({
  // Bank fields validation
  bankIban: z.string().regex(/^[A-Z]{2}[0-9]{2}[A-Z0-9]{1,30}$/, {
    message: "Nieprawidłowy format IBAN. Powinien zaczynać się od kodu kraju (2 litery) i numeru kontrolnego (2 cyfry)"
  }).optional(),
  bankSwift: z.string().regex(/^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/, {
    message: "Nieprawidłowy format SWIFT/BIC. Powinien mieć 8 lub 11 znaków alfanumerycznych"
  }).optional(),
  bankAccountNumber: z.string().max(34, {
    message: "Numer konta może mieć maksymalnie 34 znaki"
  }).optional(),
  // Social media fields validation - only https URLs (case insensitive)
  socialFacebook: z.string().url({ message: "Nieprawidłowy URL Facebook" }).regex(/^https:\/\//i, {
    message: "URL musi zaczynać się od https://"
  }).optional(),
  socialInstagram: z.string().url({ message: "Nieprawidłowy URL Instagram" }).regex(/^https:\/\//i, {
    message: "URL musi zaczynać się od https://"
  }).optional(),
  socialX: z.string().url({ message: "Nieprawidłowy URL X/Twitter" }).regex(/^https:\/\//i, {
    message: "URL musi zaczynać się od https://"
  }).optional(),
  socialTiktok: z.string().url({ message: "Nieprawidłowy URL TikTok" }).regex(/^https:\/\//i, {
    message: "URL musi zaczynać się od https://"
  }).optional(),
  socialYoutube: z.string().url({ message: "Nieprawidłowy URL YouTube" }).regex(/^https:\/\//i, {
    message: "URL musi zaczynać się od https://"
  }).optional(),
  socialLinkedin: z.string().url({ message: "Nieprawidłowy URL LinkedIn" }).regex(/^https:\/\//i, {
    message: "URL musi zaczynać się od https://"
  }).optional(),
});

// Update schema for PATCH operations - all fields optional with additional validation
export const updateUserSchema = insertUserSchema.partial().extend({
  // Role must be valid enum if provided
  role: z.enum(['USER', 'ADMIN', 'EDITOR']).optional(),
  // ExpiresAt must be future date if provided
  expiresAt: z.string().refine((date) => {
    if (!date) return true; // Allow empty
    const parsed = new Date(date);
    return parsed > new Date();
  }, {
    message: "Data wygaśnięcia musi być w przyszłości"
  }).optional(),
});

export const insertEntitlementSchema = createInsertSchema(entitlements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertAdSlotSchema = createInsertSchema(adSlots).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTestimonialSchema = createInsertSchema(testimonials).omit({
  id: true,
  createdAt: true,
});

export const insertClipSchema = createInsertSchema(clips).omit({
  id: true,
  createdAt: true,
});

export const insertAppSettingSchema = createInsertSchema(appSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertMessageLogSchema = createInsertSchema(messageLogs).omit({
  id: true,
  createdAt: true,
}).extend({
  type: z.enum(['email', 'sms', 'push', 'global']),
  status: z.enum(['pending', 'sending', 'completed', 'failed']).default('pending'),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
  read: true,
});

export const insertGlobalNotificationSchema = createInsertSchema(globalNotifications).omit({
  id: true,
  createdAt: true,
});

export const insertSocialMediaLinkSchema = createInsertSchema(socialMediaLinks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  url: z.string().url({ message: "Nieprawidłowy URL" }).regex(/^https:\/\//i, {
    message: "URL musi zaczynać się od https://"
  }),
  platform: z.string().trim().min(1, { message: "Nazwa platformy jest wymagana" }).max(50, { message: "Nazwa platformy może mieć maksymalnie 50 znaków" }),
  icon: z.string().trim().min(1, { message: "Nazwa ikony jest wymagana" }).max(100, { message: "Nazwa ikony może mieć maksymalnie 100 znaków" }),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Entitlement = typeof entitlements.$inferSelect;
export type InsertEntitlement = z.infer<typeof insertEntitlementSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type AdSlot = typeof adSlots.$inferSelect;
export type InsertAdSlot = z.infer<typeof insertAdSlotSchema>;

export type Testimonial = typeof testimonials.$inferSelect;
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;

export type Clip = typeof clips.$inferSelect;
export type InsertClip = z.infer<typeof insertClipSchema>;

export type AppSetting = typeof appSettings.$inferSelect;
export type InsertAppSetting = z.infer<typeof insertAppSettingSchema>;

export type MessageLog = typeof messageLogs.$inferSelect;
export type InsertMessageLog = z.infer<typeof insertMessageLogSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type GlobalNotification = typeof globalNotifications.$inferSelect;
export type InsertGlobalNotification = z.infer<typeof insertGlobalNotificationSchema>;

export type SocialMediaLink = typeof socialMediaLinks.$inferSelect;
export type InsertSocialMediaLink = z.infer<typeof insertSocialMediaLinkSchema>;

// Theme Config schema - stored in appSettings with key='theme_config'
export const themeConfigSchema = z.object({
  theme: z.enum(["normal", "christmas", "new_year", "summer", "easter"]).default("normal"),
  heroText: z.string().max(200).default("Oglądaj premium treści przez 30 dni za jedyne €0.99"),
  ctaText: z.string().max(50).default("Aktywuj dostęp teraz"),
});

export type ThemeConfig = z.infer<typeof themeConfigSchema>;
