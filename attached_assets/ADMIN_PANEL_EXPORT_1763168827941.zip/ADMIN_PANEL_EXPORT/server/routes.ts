import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import bcrypt from "bcrypt";
import { z } from "zod";
import { storage } from "./storage";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { updateUserSchema, insertSocialMediaLinkSchema, type Entitlement } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("Missing required Stripe secret: STRIPE_SECRET_KEY");
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-10-29.clover",
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // ========== PUBLIC ROUTES ==========
  
  // Get active ad slots for ticker
  app.get("/api/ads", async (req, res) => {
    try {
      const adSlots = await storage.getActiveAdSlots();
      res.json(adSlots);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Track ad click
  app.post("/api/ads/:id/click", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.incrementAdClick(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get active testimonials
  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getActiveTestimonials();
      res.json(testimonials);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get user counter
  app.get("/api/counter", async (req, res) => {
    try {
      const setting = await storage.getSetting("total_signups");
      const count = setting ? parseInt(setting.value, 10) : 0;
      res.json({ count });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get counter last updated timestamp (for polling)
  app.get("/api/counter/last-updated", async (req, res) => {
    try {
      const timestamp = await storage.getCounterLastUpdated();
      res.json({ timestamp });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get active playlist
  app.get("/api/playlist", async (req, res) => {
    try {
      const clips = await storage.getActiveClips();
      res.json(clips);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get theme config
  app.get("/api/theme", async (req, res) => {
    try {
      const themeConfig = await storage.getThemeConfig();
      res.json(themeConfig);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get enabled social media links
  app.get("/api/social-media-links", async (req, res) => {
    try {
      const links = await storage.getEnabledSocialMediaLinks();
      res.json(links);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Check if user has access
  app.get("/api/check-access", async (req, res) => {
    try {
      // Check if user has a session with userId
      const userId = (req.session as any)?.userId;
      
      if (!userId) {
        return res.json({ authenticated: false, hasAccess: false });
      }

      // Check if user has valid entitlement
      const entitlement = await storage.getEntitlementByUserId(userId);
      
      if (!entitlement) {
        return res.json({ authenticated: true, hasAccess: false });
      }

      // Check if entitlement is still valid
      const now = new Date();
      const hasAccess = new Date(entitlement.expiresAt) > now;
      
      res.json({ authenticated: true, hasAccess, expiresAt: entitlement.expiresAt });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== STRIPE PAYMENT ROUTES ==========
  
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      // Hardcoded price and currency - NEVER trust client input for payment amount
      const PRICE_CENTS = 99; // 0.99 EUR
      const CURRENCY = "eur";
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: PRICE_CENTS,
        currency: CURRENCY,
        receipt_email: email,
        metadata: {
          service: "babatv24_preview",
          userEmail: email,
        },
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ error: "Error creating payment intent: " + error.message });
    }
  });

  // Verify payment and create session (called after successful Stripe payment)
  app.post("/api/verify-payment", async (req, res) => {
    try {
      const { paymentIntentId } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ error: "Payment intent ID is required" });
      }

      // Verify the payment intent with Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status !== "succeeded") {
        return res.status(400).json({ error: "Payment not completed" });
      }

      // CRITICAL: Validate amount and currency match expected values
      const EXPECTED_AMOUNT = 99; // 0.99 EUR in cents
      const EXPECTED_CURRENCY = "eur";
      
      if (paymentIntent.amount !== EXPECTED_AMOUNT) {
        console.error(`Payment amount mismatch: expected ${EXPECTED_AMOUNT}, got ${paymentIntent.amount}`);
        return res.status(400).json({ error: "Invalid payment amount" });
      }
      
      if (paymentIntent.currency !== EXPECTED_CURRENCY) {
        console.error(`Payment currency mismatch: expected ${EXPECTED_CURRENCY}, got ${paymentIntent.currency}`);
        return res.status(400).json({ error: "Invalid payment currency" });
      }

      // Get user email from payment intent metadata
      const userEmail = paymentIntent.metadata?.userEmail || paymentIntent.receipt_email;
      
      if (!userEmail) {
        return res.status(400).json({ error: "No email found in payment" });
      }

      // Get or create user
      let user = await storage.getUserByEmail(userEmail);
      if (!user) {
        user = await storage.createUser({
          email: userEmail,
          role: "USER",
        });
      }

      // Check if transaction already exists
      const existingTransactions = await storage.getAllTransactions();
      const transactionExists = existingTransactions.some(t => t.providerId === paymentIntentId);
      
      if (!transactionExists) {
        // Create transaction record
        await storage.createTransaction({
          userId: user.id,
          amount: paymentIntent.amount,
          currency: paymentIntent.currency.toUpperCase(),
          provider: "stripe",
          providerId: paymentIntentId,
          status: "completed",
        });

        // Create or update entitlement (30 days from now)
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30);

        const existingEntitlement = await storage.getEntitlementByUserId(user.id);
        if (existingEntitlement) {
          await storage.updateEntitlementExpiry(user.id, expiresAt);
        } else {
          await storage.createEntitlement({
            userId: user.id,
            expiresAt,
          });
        }

        // Increment user counter
        await storage.incrementCounter("total_signups");
      }

      // Create session for the user
      (req.session as any).userId = user.id;
      (req.session as any).email = user.email;

      res.json({ success: true, userId: user.id });
    } catch (error: any) {
      console.error("Payment verification error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Stripe webhook handler
  app.post("/api/webhooks/stripe", async (req, res) => {
    try {
      // In development, we'll accept webhooks without verification
      // In production, you should verify the signature with stripe.webhooks.constructEvent
      const event = req.body;

      if (event.type === "payment_intent.succeeded") {
        const paymentIntent = event.data.object;
        
        // CRITICAL: Validate amount and currency match expected values
        const EXPECTED_AMOUNT = 99; // 0.99 EUR in cents
        const EXPECTED_CURRENCY = "eur";
        
        if (paymentIntent.amount !== EXPECTED_AMOUNT || paymentIntent.currency !== EXPECTED_CURRENCY) {
          console.error(`Webhook payment validation failed: amount=${paymentIntent.amount}, currency=${paymentIntent.currency}`);
          return res.json({ received: true, error: "Invalid payment parameters" });
        }
        
        // Get user email from metadata
        const userEmail = paymentIntent.metadata?.userEmail || paymentIntent.receipt_email;
        
        if (!userEmail) {
          console.error("No email found in payment intent");
          return res.json({ received: true });
        }
        
        // Check if this payment was already processed
        const existingTransactions = await storage.getAllTransactions();
        const alreadyProcessed = existingTransactions.some(t => t.providerId === paymentIntent.id);
        
        if (alreadyProcessed) {
          console.log(`Payment ${paymentIntent.id} already processed, skipping`);
          return res.json({ received: true });
        }
        
        // Create or get user
        let user = await storage.getUserByEmail(userEmail);
        if (!user) {
          user = await storage.createUser({
            email: userEmail,
            role: "USER",
          });
        }

        // Create transaction record
        await storage.createTransaction({
          userId: user.id,
          amount: paymentIntent.amount,
          currency: paymentIntent.currency.toUpperCase(),
          provider: "stripe",
          providerId: paymentIntent.id,
          status: "completed",
        });

        // Create or update entitlement (30 days from now)
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30);

        const existingEntitlement = await storage.getEntitlementByUserId(user.id);
        if (existingEntitlement) {
          await storage.updateEntitlementExpiry(user.id, expiresAt);
        } else {
          await storage.createEntitlement({
            userId: user.id,
            expiresAt,
          });
        }

        // Increment user counter
        await storage.incrementCounter("total_signups");
        
        // Mark counter as updated (trigger frontend polling)
        await storage.markCounterUpdated();
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error("Stripe webhook error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ========== PAYPAL ROUTES ==========
  // Referenced from javascript_paypal blueprint
  
  app.get("/paypal/setup", async (req, res) => {
    try {
      await loadPaypalDefault(req, res);
    } catch (error: any) {
      console.error("PayPal setup error:", error);
      console.error("PayPal error body:", error.result || error.body);
      console.error("PayPal status code:", error.statusCode);
      res.status(500).json({ 
        error: "PayPal setup failed. Please check your PayPal credentials.",
        details: error.result?.error_description || error.message || "Authentication failed",
        statusCode: error.statusCode,
        paypalError: error.result?.error
      });
    }
  });

  app.post("/paypal/order", async (req, res) => {
    try {
      await createPaypalOrder(req, res);
    } catch (error: any) {
      console.error("PayPal order creation error:", error.message);
      res.status(500).json({ 
        error: "Failed to create PayPal order.",
        details: error.message 
      });
    }
  });

  app.post("/paypal/order/:orderID/capture", async (req, res) => {
    try {
      await capturePaypalOrder(req, res);
    } catch (error: any) {
      console.error("PayPal capture error:", error.message);
      res.status(500).json({ 
        error: "Failed to capture PayPal order.",
        details: error.message 
      });
    }
  });

  // PayPal webhook endpoint for real-time counter updates
  app.post("/api/webhooks/paypal", async (req, res) => {
    try {
      const webhookEvent = req.body;
      const { event_type, resource } = webhookEvent;

      console.log(`[PayPal Webhook] Received event: ${event_type}`);

      // Validate required headers (fail-closed approach)
      const headers = req.headers;
      const transmissionId = headers['paypal-transmission-id'];
      const transmissionTime = headers['paypal-transmission-time'];
      const certUrl = headers['paypal-cert-url'];
      const authAlgo = headers['paypal-auth-algo'];
      const transmissionSig = headers['paypal-transmission-sig'];

      if (!transmissionId || !transmissionTime || !certUrl || !authAlgo || !transmissionSig) {
        console.error('[PayPal Webhook] Missing required PayPal headers');
        return res.status(400).json({ error: 'Missing required webhook headers' });
      }

      // Verify webhook signature (security)
      const { PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_WEBHOOK_ID } = process.env;

      if (!PAYPAL_CLIENT_ID || !PAYPAL_CLIENT_SECRET) {
        console.error('[PayPal Webhook] Missing PayPal credentials');
        return res.status(500).json({ error: 'Server configuration error' });
      }

      if (!PAYPAL_WEBHOOK_ID) {
        console.error('[PayPal Webhook] Missing PAYPAL_WEBHOOK_ID - required for production');
        return res.status(500).json({ error: 'Webhook ID not configured' });
      }

      // Get OAuth access token
      const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`).toString('base64');
      const paypalEnv = process.env.PAYPAL_ENVIRONMENT === "live" ? "api-m.paypal.com" : "api-m.sandbox.paypal.com";
      
      const tokenResponse = await fetch(`https://${paypalEnv}/v1/oauth2/token`, {
        method: 'POST',
        body: 'grant_type=client_credentials',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      if (!tokenResponse.ok) {
        console.error('[PayPal Webhook] Failed to get access token');
        return res.status(401).json({ error: 'Webhook verification failed' });
      }

      const tokenData = await tokenResponse.json();
      const accessToken = tokenData.access_token;

      // Verify webhook signature via PayPal API
      const verifyPayload = {
        transmission_id: String(transmissionId),
        transmission_time: String(transmissionTime),
        cert_url: String(certUrl),
        auth_algo: String(authAlgo),
        transmission_sig: String(transmissionSig),
        webhook_id: PAYPAL_WEBHOOK_ID,
        webhook_event: webhookEvent
      };

      const verifyResponse = await fetch(
        `https://${paypalEnv}/v1/notifications/verify-webhook-signature`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify(verifyPayload)
        }
      );

      if (!verifyResponse.ok) {
        console.error('[PayPal Webhook] Signature verification endpoint failed');
        return res.status(401).json({ error: 'Webhook verification error' });
      }

      const verifyData = await verifyResponse.json();
      if (verifyData.verification_status !== 'SUCCESS') {
        console.error('[PayPal Webhook] Signature verification failed');
        return res.status(401).json({ error: 'Invalid webhook signature' });
      }

      console.log(`[PayPal Webhook] ✅ Signature verified`);

      // Handle payment capture completion
      if (event_type === 'PAYMENT.CAPTURE.COMPLETED') {
        // Validate capture status
        if (resource?.status !== 'COMPLETED') {
          console.error(`[PayPal Webhook] Invalid capture status: ${resource?.status}`);
          return res.status(400).json({ error: 'Invalid capture status' });
        }

        // Validate amount and currency (business logic)
        const amount = resource?.amount?.value;
        const currency = resource?.amount?.currency_code;

        if (amount !== '0.99' || currency !== 'EUR') {
          console.error(`[PayPal Webhook] Invalid amount/currency: ${amount} ${currency} (expected 0.99 EUR)`);
          return res.status(400).json({ error: 'Invalid payment amount or currency' });
        }

        const captureId = resource?.id;
        if (!captureId) {
          console.error('[PayPal Webhook] Missing capture ID in resource');
          return res.status(400).json({ error: 'Missing capture ID' });
        }

        // Idempotency check - prevent replay attacks
        const existingTransaction = await storage.getTransactionByProviderId(captureId, 'paypal');
        if (existingTransaction) {
          console.log(`[PayPal Webhook] Capture ${captureId} already processed (idempotency check) - skipping`);
          return res.status(200).send('OK'); // Return success but skip processing
        }

        console.log(`[PayPal Webhook] Payment captured: ${captureId} (€${amount})`);
        
        // Extract user email from PayPal webhook (resource.payer.email_address)
        const userEmail = resource?.payer?.email_address || webhookEvent.resource?.custom_id;
        
        if (!userEmail) {
          console.error('[PayPal Webhook] No email found in webhook resource');
          return res.status(400).json({ error: 'Missing user email in webhook' });
        }

        // Create or get user (mirror capturePaypalOrder logic)
        let user = (await storage.getAllUsers()).find(u => u.email === userEmail);
        const isNewUser = !user;
        
        if (!user) {
          console.log(`[PayPal Webhook] Creating new user: ${userEmail}`);
          user = await storage.createUser({ 
            email: userEmail,
            firstName: null, // Webhook doesn't include name data
            lastName: null,
            role: "USER"
          });
        }

        // Create or update entitlement (30 days from now) - mirror Stripe flow
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30);
        
        const existingEntitlement = await storage.getEntitlementByUserId(user.id);
        if (existingEntitlement) {
          await storage.updateEntitlementExpiry(user.id, expiresAt);
          console.log(`[PayPal Webhook] Entitlement updated for ${userEmail}, expires: ${expiresAt.toISOString()}`);
        } else {
          await storage.createEntitlement({
            userId: user.id,
            expiresAt
          });
          console.log(`[PayPal Webhook] Entitlement created for ${userEmail}, expires: ${expiresAt.toISOString()}`);
        }

        // Create transaction record
        const amountCents = Math.round(parseFloat(amount) * 100);
        await storage.createTransaction({
          userId: user.id,
          amount: amountCents,
          provider: "paypal",
          providerId: captureId,
          status: "completed"
        });
        console.log(`[PayPal Webhook] Transaction recorded: €${amount} (${amountCents} cents)`);

        // Increment counter (only for new users)
        if (isNewUser) {
          await storage.incrementCounter("total_signups");
          console.log(`[PayPal Webhook] Counter incremented for new user`);
        }
        
        // Mark counter as updated (trigger frontend refetch)
        await storage.markCounterUpdated();
        console.log(`[PayPal Webhook] Counter timestamp updated for capture ${captureId}`);
      }

      // Note: capturePaypalOrder already handles user creation, entitlements, and counter increment
      // This webhook only marks counter_updated_at for frontend polling
      
      res.status(200).send('OK');
    } catch (error: any) {
      console.error("[PayPal Webhook] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ========== ADMIN ROUTES ==========
  
  // Admin login endpoint
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { password } = req.body;
      
      if (!password) {
        return res.status(400).json({ error: "Password is required" });
      }

      const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
      
      if (!ADMIN_PASSWORD) {
        console.error("ADMIN_PASSWORD not set in environment");
        return res.status(500).json({ error: "Server configuration error" });
      }

      // Simple plaintext comparison for development
      // For production: store bcrypt hash in ADMIN_PASSWORD and use bcrypt.compare()
      const isValid = password === ADMIN_PASSWORD;
      
      if (!isValid) {
        console.log(`[Admin Login] Login failed - invalid password`);
        return res.status(401).json({ error: "Invalid password" });
      }
      
      console.log(`[Admin Login] Login successful!`);

      // Set admin session and explicitly save it
      (req.session as any).isAdmin = true;
      (req.session as any).adminEmail = "admin@babatv24.de"; // Required for message logging
      (req.session as any).loginTime = new Date().toISOString();
      
      // Save session before responding to ensure it's persisted
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ error: "Failed to save session" });
        }
        res.json({ success: true });
      });
    } catch (error: any) {
      console.error("Admin login error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Admin logout endpoint
  app.post("/api/admin/logout", async (req, res) => {
    try {
      (req as any).session.destroy((err: any) => {
        if (err) {
          return res.status(500).json({ error: "Logout failed" });
        }
        res.json({ success: true });
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Check if admin is logged in
  app.get("/api/admin/check", async (req, res) => {
    const isAdmin = (req.session as any)?.isAdmin === true;
    res.json({ isAdmin });
  });
  
  // Admin authentication middleware
  const adminAuth = (req: any, res: any, next: any) => {
    // Require valid admin session (no development bypass!)
    const isAdmin = req.session?.isAdmin === true;
    
    if (!isAdmin) {
      return res.status(403).json({ error: "Admin access required" });
    }
    
    next();
  };
  
  // Admin stats
  app.get("/api/admin/stats", adminAuth, async (req, res) => {
    try {
      const transactions = await storage.getAllTransactions();
      const users = await storage.getAllUsers();
      const entitlements = await storage.getAllEntitlements();
      
      const paidTransactions = transactions.filter(t => t.status === "completed");
      const totalRevenue = paidTransactions.reduce((sum, t) => sum + t.amount, 0);
      const transactionsToday = paidTransactions.filter(t => {
        const transactionDate = new Date(t.createdAt);
        const today = new Date();
        return transactionDate.toDateString() === today.toDateString();
      }).length;
      
      // Count users with valid entitlements
      const now = new Date();
      const activeUsers = entitlements.filter((e: any) => new Date(e.expiresAt) > now).length;
      
      // Real revenue data for last 7 days
      const revenueData = Array.from({ length: 7 }, (_, i) => {
        const date = new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000);
        const dateStr = date.toDateString();
        
        const dayRevenue = paidTransactions
          .filter(t => new Date(t.createdAt).toDateString() === dateStr)
          .reduce((sum, t) => sum + t.amount, 0);
        
        return {
          date: date.toLocaleDateString('pl-PL', { day: 'numeric', month: 'short' }),
          amount: dayRevenue / 100, // Convert cents to euros
        };
      });
      
      // Real user growth data for last 7 days
      const userGrowth = Array.from({ length: 7 }, (_, i) => {
        const date = new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000);
        // Set to end of day (23:59:59) to include all users created that day
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);
        
        const usersUpToDate = users.filter(u => {
          const userDate = new Date(u.createdAt);
          return userDate <= endOfDay;
        }).length;
        
        return {
          date: date.toLocaleDateString('pl-PL', { day: 'numeric', month: 'short' }),
          count: usersUpToDate,
        };
      });
      
      res.json({
        totalRevenue: totalRevenue / 100, // Convert to euros to match revenueData
        totalUsers: users.length,
        activeUsers,
        transactionsToday,
        revenueData,
        userGrowth,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Admin ad slots
  app.get("/api/admin/ads", adminAuth, async (req, res) => {
    try {
      const adSlots = await storage.getAllAdSlots();
      res.json(adSlots);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/admin/ads/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.updateAdSlot(id, req.body);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/admin/ads/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteAdSlot(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/ads", adminAuth, async (req, res) => {
    try {
      const newAd = await storage.createAdSlot(req.body);
      res.json(newAd);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Admin testimonials
  app.get("/api/admin/testimonials", adminAuth, async (req, res) => {
    try {
      const testimonials = await storage.getAllTestimonials();
      res.json(testimonials);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/testimonials", adminAuth, async (req, res) => {
    try {
      const newTestimonial = await storage.createTestimonial(req.body);
      res.json(newTestimonial);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/admin/testimonials/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.updateTestimonial(id, req.body);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/admin/testimonials/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTestimonial(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Admin social media links
  app.get("/api/admin/social-media-links", adminAuth, async (req, res) => {
    try {
      const links = await storage.getAllSocialMediaLinks();
      res.json(links);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/social-media-links", adminAuth, async (req, res) => {
    try {
      const validated = insertSocialMediaLinkSchema.parse(req.body);
      const newLink = await storage.createSocialMediaLink(validated);
      res.json(newLink);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/admin/social-media-links/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const validated = insertSocialMediaLinkSchema.partial().parse(req.body);
      await storage.updateSocialMediaLink(id, validated);
      res.json({ success: true });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/admin/social-media-links/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteSocialMediaLink(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Admin users
  app.get("/api/admin/users", adminAuth, async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      
      // Fetch entitlements for all users
      const usersWithEntitlements = await Promise.all(
        allUsers.map(async (user) => {
          const entitlement = await storage.getEntitlementByUserId(user.id);
          return { ...user, entitlement: entitlement || null };
        })
      );
      
      res.json(usersWithEntitlements);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Sync counter with actual user count (admin only)
  app.post("/api/admin/sync-counter", adminAuth, async (req, res) => {
    try {
      // Count all users in database (authoritative source)
      const allUsers = await storage.getAllUsers();
      const actualCount = allUsers.length;
      
      // Get current counter value for logging
      const currentSetting = await storage.getSetting("total_signups");
      const currentCount = currentSetting ? parseInt(currentSetting.value, 10) : 0;
      
      // Use max to ensure counter is monotonic (never decreases)
      const proposedCount = Math.max(currentCount, actualCount);
      
      // Re-read immediately before write to minimize race window (atomic guard)
      // This prevents concurrent signups from being overwritten
      const latestSetting = await storage.getSetting("total_signups");
      const latestCount = latestSetting ? parseInt(latestSetting.value, 10) : 0;
      
      // Only write if our proposed value is >= latest (prevents regression)
      const finalCount = Math.max(latestCount, proposedCount);
      
      await storage.setSetting({ 
        key: "total_signups", 
        value: String(finalCount) 
      });
      
      console.log(`[Admin] Counter synchronized: ${finalCount} users (actual: ${actualCount}, previous: ${currentCount}, latest: ${latestCount})`);
      
      res.json({ 
        success: true, 
        count: finalCount,
        message: `Counter zaktualizowany: ${finalCount} użytkowników` 
      });
    } catch (error: any) {
      console.error("Error syncing counter:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Create new user (admin only)
  app.post("/api/admin/users", adminAuth, async (req, res) => {
    try {
      const { email, firstName, lastName, role } = req.body;
      
      // Validate required fields
      if (!email || typeof email !== "string") {
        return res.status(400).json({ error: "Email jest wymagany" });
      }
      
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ error: "Nieprawidłowy format email" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Użytkownik o tym emailu już istnieje" });
      }
      
      // Validate role
      const validRole = role === "ADMIN" ? "ADMIN" : "USER";
      
      // Create user
      const newUser = await storage.createUser({
        email,
        firstName: firstName || null,
        lastName: lastName || null,
        role: validRole,
      });
      
      // Increment counter for new user signup
      await storage.incrementCounter("total_signups");
      
      console.log(`[Admin] User created: ${email} (ID: ${newUser.userId}, Role: ${validRole})`);
      
      res.status(201).json(newUser);
    } catch (error: any) {
      console.error("Error creating user:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Grant 30-day access to a user (manual admin action)
  app.post("/api/admin/users/:userId/grant-access", adminAuth, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Validate userId is 7 digits
      const numericUserId = parseInt(userId, 10);
      if (isNaN(numericUserId) || userId.length !== 7) {
        return res.status(400).json({ error: "Invalid userId format. Expected 7-digit number." });
      }
      
      // Find user by 7-digit userId
      const user = await storage.getUserByUserId(numericUserId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Check if user already has an entitlement
      const existingEntitlement = await storage.getEntitlementByUserId(user.id);
      
      const now = new Date();
      let newExpiryDate: Date;
      
      if (existingEntitlement && new Date(existingEntitlement.expiresAt) > now) {
        // Extend existing access by 30 days from current expiry
        newExpiryDate = new Date(existingEntitlement.expiresAt);
        newExpiryDate.setDate(newExpiryDate.getDate() + 30);
        await storage.updateEntitlementExpiry(user.id, newExpiryDate);
      } else {
        // Create new 30-day entitlement from now
        newExpiryDate = new Date(now);
        newExpiryDate.setDate(newExpiryDate.getDate() + 30);
        
        if (existingEntitlement) {
          // Update existing expired entitlement
          await storage.updateEntitlementExpiry(user.id, newExpiryDate);
        } else {
          // Create new entitlement
          await storage.createEntitlement({
            userId: user.id,
            expiresAt: newExpiryDate,
          });
        }
      }
      
      // Log manual grant as a transaction for audit trail
      await storage.createTransaction({
        userId: user.id,
        amount: 0,
        currency: "EUR",
        provider: "manual",
        providerId: `manual-grant-${Date.now()}`,
        status: "completed",
      });
      
      res.json({ 
        success: true, 
        expiresAt: newExpiryDate,
        message: `Przyznano 30-dniowy dostęp dla użytkownika ${user.email} (ID: ${user.userId})`
      });
    } catch (error: any) {
      console.error("Error granting access:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Update user (email, role, or access)
  app.patch("/api/admin/users/:userId", adminAuth, async (req, res) => {
    try {
      const { userId } = req.params;
      const { 
        email, role, expiresAt, 
        firstName, lastName, avatarUrl, 
        phone, address, city, country, postalCode,
        bankName, bankAccountNumber, bankIban, bankSwift,
        socialFacebook, socialInstagram, socialX, socialTiktok, socialYoutube, socialLinkedin
      } = req.body;
      
      // Validate userId is 7 digits
      const numericUserId = parseInt(userId, 10);
      if (isNaN(numericUserId) || userId.length !== 7) {
        return res.status(400).json({ error: "Invalid userId format. Expected 7-digit number." });
      }
      
      // Find user by 7-digit userId
      const user = await storage.getUserByUserId(numericUserId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Normalize empty strings to undefined before validation (allows optional fields to be cleared)
      const normalizeValue = (val: any) => (val === "" ? undefined : val);
      
      // Validate all fields using Zod schema and capture normalized values
      let validatedData;
      try {
        validatedData = updateUserSchema.parse({ 
          email, role, 
          expiresAt: normalizeValue(expiresAt),
          firstName: normalizeValue(firstName), 
          lastName: normalizeValue(lastName), 
          avatarUrl: normalizeValue(avatarUrl), 
          phone: normalizeValue(phone), 
          address: normalizeValue(address), 
          city: normalizeValue(city), 
          country: normalizeValue(country), 
          postalCode: normalizeValue(postalCode),
          bankName: normalizeValue(bankName), 
          bankAccountNumber: normalizeValue(bankAccountNumber), 
          bankIban: normalizeValue(bankIban), 
          bankSwift: normalizeValue(bankSwift),
          socialFacebook: normalizeValue(socialFacebook), 
          socialInstagram: normalizeValue(socialInstagram), 
          socialX: normalizeValue(socialX), 
          socialTiktok: normalizeValue(socialTiktok), 
          socialYoutube: normalizeValue(socialYoutube), 
          socialLinkedin: normalizeValue(socialLinkedin)
        });
      } catch (validationError: any) {
        if (validationError.name === "ZodError") {
          return res.status(400).json({ 
            error: "Błąd walidacji danych", 
            details: validationError.errors.map((e: any) => ({
              field: e.path.join('.'),
              message: e.message
            }))
          });
        }
        throw validationError;
      }
      
      // Build updates object using validated (normalized) values
      const userUpdates: Partial<Pick<typeof user, 
        'email' | 'role' | 'firstName' | 'lastName' | 'avatarUrl' | 
        'phone' | 'address' | 'city' | 'country' | 'postalCode' |
        'bankName' | 'bankAccountNumber' | 'bankIban' | 'bankSwift' |
        'socialFacebook' | 'socialInstagram' | 'socialX' | 'socialTiktok' | 'socialYoutube' | 'socialLinkedin'
      >> = {};
      
      if (validatedData.email !== undefined) userUpdates.email = validatedData.email;
      if (validatedData.role !== undefined) userUpdates.role = validatedData.role;
      if (validatedData.firstName !== undefined) userUpdates.firstName = validatedData.firstName || null;
      if (validatedData.lastName !== undefined) userUpdates.lastName = validatedData.lastName || null;
      if (validatedData.avatarUrl !== undefined) userUpdates.avatarUrl = validatedData.avatarUrl || null;
      if (validatedData.phone !== undefined) userUpdates.phone = validatedData.phone || null;
      if (validatedData.address !== undefined) userUpdates.address = validatedData.address || null;
      if (validatedData.city !== undefined) userUpdates.city = validatedData.city || null;
      if (validatedData.country !== undefined) userUpdates.country = validatedData.country || null;
      if (validatedData.postalCode !== undefined) userUpdates.postalCode = validatedData.postalCode || null;
      if (validatedData.bankName !== undefined) userUpdates.bankName = validatedData.bankName || null;
      if (validatedData.bankAccountNumber !== undefined) userUpdates.bankAccountNumber = validatedData.bankAccountNumber || null;
      if (validatedData.bankIban !== undefined) userUpdates.bankIban = validatedData.bankIban || null;
      if (validatedData.bankSwift !== undefined) userUpdates.bankSwift = validatedData.bankSwift || null;
      if (validatedData.socialFacebook !== undefined) userUpdates.socialFacebook = validatedData.socialFacebook || null;
      if (validatedData.socialInstagram !== undefined) userUpdates.socialInstagram = validatedData.socialInstagram || null;
      if (validatedData.socialX !== undefined) userUpdates.socialX = validatedData.socialX || null;
      if (validatedData.socialTiktok !== undefined) userUpdates.socialTiktok = validatedData.socialTiktok || null;
      if (validatedData.socialYoutube !== undefined) userUpdates.socialYoutube = validatedData.socialYoutube || null;
      if (validatedData.socialLinkedin !== undefined) userUpdates.socialLinkedin = validatedData.socialLinkedin || null;
      
      if (Object.keys(userUpdates).length > 0) {
        await storage.updateUser(numericUserId, userUpdates);
      }
      
      // Update entitlement if expiresAt is provided
      if (expiresAt) {
        const newExpiryDate = new Date(expiresAt);
        const existingEntitlement = await storage.getEntitlementByUserId(user.id);
        
        if (existingEntitlement) {
          await storage.updateEntitlementExpiry(user.id, newExpiryDate);
        } else {
          await storage.createEntitlement({
            userId: user.id,
            expiresAt: newExpiryDate,
          });
        }
      }
      
      res.json({ 
        success: true,
        message: "Użytkownik został zaktualizowany"
      });
    } catch (error: any) {
      console.error("Error updating user:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete user (admin only)
  app.delete("/api/admin/users/:userId", adminAuth, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Validate userId is 7 digits
      const numericUserId = parseInt(userId, 10);
      if (isNaN(numericUserId) || userId.length !== 7) {
        return res.status(400).json({ error: "Invalid userId format. Expected 7-digit number." });
      }
      
      // Find user by 7-digit userId
      const user = await storage.getUserByUserId(numericUserId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Transactional cascading delete (notifications → transactions → entitlements → user)
      await storage.deleteUser(user.id);
      
      console.log(`[Admin] User deleted: ${user.email} (ID: ${user.userId})`);
      
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Admin playlist
  app.get("/api/admin/playlist", adminAuth, async (req, res) => {
    try {
      const clips = await storage.getAllClips();
      res.json(clips);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/playlist", adminAuth, async (req, res) => {
    try {
      const newClip = await storage.createClip(req.body);
      res.json(newClip);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/admin/playlist/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.updateClip(id, req.body);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/admin/playlist/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteClip(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Admin theme config
  app.get("/api/admin/theme", adminAuth, async (req, res) => {
    try {
      const themeConfig = await storage.getThemeConfig();
      res.json(themeConfig);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/admin/theme", adminAuth, async (req, res) => {
    try {
      const { theme, heroText, ctaText } = req.body;
      
      // setThemeConfig will validate with schema and throw ZodError for invalid data
      await storage.setThemeConfig({ theme, heroText, ctaText });
      
      // Return updated config
      const updated = await storage.getThemeConfig();
      res.json(updated);
    } catch (error: any) {
      // Zod validation errors → 400 Bad Request
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid theme configuration", details: error.errors });
      }
      // All other errors → 500 Internal Server Error
      console.error("Error updating theme config:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Message logs endpoints
  app.get("/api/admin/messages/logs", adminAuth, async (req, res) => {
    try {
      const logs = await storage.getAllMessageLogs();
      res.json({ logs });
    } catch (error: any) {
      console.error("Error fetching message logs:", error);
      res.status(500).json({ error: "Failed to fetch message logs" });
    }
  });

  // Validation schema for message sending
  const sendMessageSchema = z.object({
    type: z.enum(["EMAIL", "SMS"]),
    subject: z.string().min(1).max(200).optional(),
    message: z.string().min(1).max(1000),
    recipientFilter: z.enum(["all", "active", "expired"]),
  }).refine(
    (data) => data.type !== "EMAIL" || (data.subject && data.subject.length > 0),
    {
      message: "Subject is required for email messages",
      path: ["subject"],
    }
  );

  app.post("/api/admin/messages/send", adminAuth, async (req, res) => {
    try {
      // Validate request body
      const validation = sendMessageSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid request data", 
          details: validation.error.errors 
        });
      }

      const { type, subject, message, recipientFilter } = validation.data;

      // Require authenticated admin identity (no fallback)
      const adminEmail = (req.session as any)?.adminEmail;
      if (!adminEmail) {
        return res.status(401).json({ error: "Admin authentication required" });
      }

      // Get all users
      const allUsers = await storage.getAllUsers();
      let recipients = allUsers;

      // Filter recipients based on recipientFilter
      if (recipientFilter === "active" || recipientFilter === "expired") {
        // Get all entitlements to check access status
        const allEntitlements = await storage.getAllEntitlements();
        const entitlementMap = new Map<string, Entitlement>(
          allEntitlements.map((e) => [e.userId, e])
        );

        const now = Date.now();

        if (recipientFilter === "active") {
          // Only users with valid (non-expired) entitlements
          recipients = allUsers.filter(u => {
            const entitlement = entitlementMap.get(u.id);
            if (!entitlement) return false;
            return new Date(entitlement.expiresAt).getTime() > now;
          });
        } else if (recipientFilter === "expired") {
          // Users without entitlement or with expired entitlement
          recipients = allUsers.filter(u => {
            const entitlement = entitlementMap.get(u.id);
            if (!entitlement) return true;
            return new Date(entitlement.expiresAt).getTime() <= now;
          });
        }
      }
      // "all" means no filtering

      let successCount = 0;
      let failureCount = 0;

      // TODO: Implement actual email/SMS sending via integrations
      // For now, we'll simulate sending by logging
      for (const user of recipients) {
        try {
          if (type === "EMAIL") {
            if (!user.email) {
              failureCount++;
              continue;
            }
            // TODO: Send email via SendGrid integration
            console.log(`[Messages] Would send email to ${user.email}: ${subject}`);
            successCount++;
          } else if (type === "SMS") {
            if (!user.phone) {
              failureCount++;
              continue;
            }
            // TODO: Send SMS via Twilio integration
            console.log(`[Messages] Would send SMS to ${user.phone}: ${message.substring(0, 50)}...`);
            successCount++;
          }
        } catch (error) {
          console.error(`Failed to send ${type} to user ${user.id}:`, error);
          failureCount++;
        }
      }

      // Create message log
      const log = await storage.createMessageLog({
        type: type.toLowerCase() as "email" | "sms",
        subject: type === "EMAIL" && subject ? subject : null,
        message,
        recipientCount: recipients.length,
        successCount,
        failureCount,
        status: "completed",
        sentBy: adminEmail,
      });

      res.json({
        success: true,
        log,
        recipientsProcessed: recipients.length,
        successCount,
        failureCount,
        message: `Message sent to ${successCount} of ${recipients.length} recipients. ${failureCount} failed.`,
      });
    } catch (error: any) {
      console.error("Error sending message:", error);
      
      // Zod validation errors
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Validation failed", details: error.errors });
      }
      
      // Generic error
      res.status(500).json({ error: "Failed to send message" });
    }
  });

  // Notifications endpoints
  // Get user's notifications (requires authentication)
  app.get("/api/notifications", async (req, res) => {
    try {
      const userId = (req.session as any)?.userId;
      if (!userId) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const notifications = await storage.getNotificationsByUserId(userId);
      res.json({ notifications });
    } catch (error: any) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  // Mark notification as read
  app.patch("/api/notifications/:id/read", async (req, res) => {
    try {
      const userId = (req.session as any)?.userId;
      if (!userId) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const { id } = req.params;
      
      // Verify notification belongs to user
      const notifications = await storage.getNotificationsByUserId(userId);
      const notification = notifications.find(n => n.id === id);
      
      if (!notification) {
        return res.status(404).json({ error: "Notification not found" });
      }

      await storage.markNotificationAsRead(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });

  // Admin: Send push notifications to users (with recipient filtering)
  app.post("/api/admin/notifications/send", adminAuth, async (req, res) => {
    try {
      const { message, recipientFilter } = req.body;

      // Validate request
      if (!message || typeof message !== "string" || message.length === 0 || message.length > 500) {
        return res.status(400).json({ error: "message must be a string between 1 and 500 characters" });
      }

      if (!recipientFilter || !['all', 'active', 'expired'].includes(recipientFilter)) {
        return res.status(400).json({ error: "recipientFilter must be 'all', 'active', or 'expired'" });
      }

      // Get all users
      const allUsers = await storage.getAllUsers();
      let recipients = allUsers;

      // Filter recipients based on recipientFilter
      if (recipientFilter === "active" || recipientFilter === "expired") {
        const allEntitlements = await storage.getAllEntitlements();
        const entitlementMap = new Map<string, Entitlement>(
          allEntitlements.map((e) => [e.userId, e])
        );

        const now = Date.now();

        if (recipientFilter === "active") {
          recipients = allUsers.filter(u => {
            const entitlement = entitlementMap.get(u.id);
            if (!entitlement) return false;
            return new Date(entitlement.expiresAt).getTime() > now;
          });
        } else if (recipientFilter === "expired") {
          recipients = allUsers.filter(u => {
            const entitlement = entitlementMap.get(u.id);
            if (!entitlement) return true;
            return new Date(entitlement.expiresAt).getTime() <= now;
          });
        }
      }

      // Require authenticated admin identity
      const adminEmail = (req.session as any)?.adminEmail;
      if (!adminEmail) {
        return res.status(401).json({ error: "Admin authentication required" });
      }

      // Send notification to each recipient
      let successCount = 0;
      let failureCount = 0;

      for (const user of recipients) {
        try {
          await storage.createNotification({
            userId: user.id,
            message,
          });
          successCount++;
        } catch (error) {
          console.error(`Failed to create notification for user ${user.id}:`, error);
          failureCount++;
        }
      }

      // Log to message_logs for admin history
      const log = await storage.createMessageLog({
        type: "push",
        subject: null,
        message,
        recipientCount: recipients.length,
        successCount,
        failureCount,
        status: "completed",
        sentBy: adminEmail,
      });

      res.json({
        success: true,
        log,
        successCount,
        failureCount,
        recipientsProcessed: recipients.length,
        message: `Notifications sent to ${successCount} of ${recipients.length} users. ${failureCount} failed.`,
      });
    } catch (error: any) {
      console.error("Error sending notifications:", error);
      res.status(500).json({ error: "Failed to send notifications" });
    }
  });

  // ========== GLOBAL NOTIFICATIONS ROUTES ==========
  
  // Get all global notifications (public, no auth required)
  app.get("/api/global-notifications", async (req, res) => {
    try {
      const notifications = await storage.getAllGlobalNotifications();
      res.setHeader('Cache-Control', 'public, max-age=30'); // Cache for 30 seconds
      res.json({ notifications });
    } catch (error: any) {
      console.error("Error fetching global notifications:", error);
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  // Admin: Create global notification
  app.post("/api/admin/global-notifications", adminAuth, async (req, res) => {
    try {
      const { message } = req.body;

      // Validate request
      if (!message || typeof message !== "string" || message.length === 0 || message.length > 500) {
        return res.status(400).json({ error: "message must be a string between 1 and 500 characters" });
      }

      // Require authenticated admin identity
      const adminEmail = (req.session as any)?.adminEmail;
      if (!adminEmail) {
        return res.status(401).json({ error: "Admin authentication required" });
      }

      // Create global notification
      const notification = await storage.createGlobalNotification({ message });

      // Log to message_logs for admin history
      const log = await storage.createMessageLog({
        type: "global",
        subject: null,
        message,
        recipientCount: 1, // Global broadcast counts as 1
        successCount: 1,
        failureCount: 0,
        status: "completed",
        sentBy: adminEmail,
      });

      res.json({
        success: true,
        notification,
        log,
        message: "Global notification created successfully",
      });
    } catch (error: any) {
      console.error("Error creating global notification:", error);
      res.status(500).json({ error: "Failed to create global notification" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
