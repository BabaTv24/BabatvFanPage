import { storage } from "./storage";

async function seed() {
  console.log("🌱 Seeding database...");

  try {
    // Initialize total_signups counter
    await storage.setSetting({ key: "total_signups", value: "247" });
    console.log("✓ Initialized user counter");

    // Seed 5 test users with 7-digit IDs (auto-generated from sequence)
    const testUsers = [
      { email: "user1@babatv24.test", role: "USER" },
      { email: "user2@babatv24.test", role: "USER" },
      { email: "user3@babatv24.test", role: "USER" },
      { email: "admin@babatv24.test", role: "ADMIN" },
      { email: "user4@babatv24.test", role: "USER" },
    ];

    for (const userData of testUsers) {
      await storage.createUser(userData);
    }
    console.log("✓ Seeded 5 test users with auto-generated 7-digit IDs");

    // Seed 25 ad slots
    const adSlotPromises = [];
    for (let i = 1; i <= 25; i++) {
      adSlotPromises.push(
        storage.createAdSlot({
          position: i,
          active: i <= 15, // First 15 active
          title: `Reklama ${i}`,
          text: `Miejsce na Twoją reklamę • Slot ${i}`,
          url: `https://example.com/ad-${i}`,
          logoUrl: `https://ui-avatars.com/api/?name=Ad+${i}&background=random&size=48`,
        })
      );
    }
    await Promise.all(adSlotPromises);
    console.log("✓ Seeded 25 ad slots");

    // Seed 12 testimonials
    const testimonialData = [
      { name: "Anna Kowalska", quote: "Świetna jakość streamingu! Warto każdej złotówki.", rating: 5 },
      { name: "Piotr Nowak", quote: "Najlepsza oferta na rynku. Polecam wszystkim!", rating: 5 },
      { name: "Maria Wiśniewska", quote: "Bardzo przyjazny interfejs. Łatwo się odnaleźć.", rating: 5 },
      { name: "Jan Kowalczyk", quote: "Za 0,99€ to prawdziwa okazja. Zero kompromisów.", rating: 4 },
      { name: "Katarzyna Lewandowska", quote: "Świetny stosunek jakości do ceny. Jestem zadowolona!", rating: 5 },
      { name: "Tomasz Wójcik", quote: "Płynny streaming bez opóźnień. Polecam!", rating: 5 },
      { name: "Agnieszka Kamińska", quote: "Bardzo dobra jakość wideo. Jestem pod wrażeniem.", rating: 4 },
      { name: "Michał Zieliński", quote: "Prosta obsługa, świetna jakość. Rewelacja!", rating: 5 },
      { name: "Joanna Szymańska", quote: "Za te pieniądze to strzał w dziesiątkę!", rating: 5 },
      { name: "Krzysztof Woźniak", quote: "Bardzo zadowolony z zakupu. Gorąco polecam.", rating: 4 },
      { name: "Magdalena Dąbrowska", quote: "Świetna alternatywa dla drogich platform.", rating: 5 },
      { name: "Andrzej Kozłowski", quote: "Jakość premium w świetnej cenie. Super!", rating: 5 },
    ];

    const testimonialPromises = testimonialData.map((t, i) =>
      storage.createTestimonial({
        name: t.name,
        avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(t.name)}&background=random&size=64`,
        rating: t.rating,
        quote: t.quote,
        active: i < 9, // First 9 active
      })
    );
    await Promise.all(testimonialPromises);
    console.log("✓ Seeded 12 testimonials");

    // Seed 5 video clips
    const clipData = [
      {
        title: "BABATV24 Intro",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        lengthSec: 45,
        order: 1,
      },
      {
        title: "Najlepsze momenty",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        lengthSec: 45,
        order: 2,
      },
      {
        title: "Behind the scenes",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        lengthSec: 45,
        order: 3,
      },
      {
        title: "Wywiady z gwiazdami",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        lengthSec: 45,
        order: 4,
      },
      {
        title: "Zapowiedź nowych odcinków",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        lengthSec: 45,
        order: 5,
      },
    ];

    const clipPromises = clipData.map((c) =>
      storage.createClip({
        title: c.title,
        url: c.url,
        lengthSec: c.lengthSec,
        order: c.order,
        active: true,
      })
    );
    await Promise.all(clipPromises);
    console.log("✓ Seeded 5 video clips");

    console.log("✅ Database seeding complete!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

seed()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
