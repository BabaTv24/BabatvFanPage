import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Edit, Calendar, User as UserIcon, Mail, Phone, MapPin, Image, CreditCard, Share2 } from "lucide-react";
import { SiFacebook, SiInstagram, SiX, SiTiktok, SiYoutube, SiLinkedin } from "react-icons/si";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, Entitlement } from "@shared/schema";
import { format } from "date-fns";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface UserWithEntitlement extends User {
  entitlement?: Entitlement | null;
}

interface EditUserDialogProps {
  user: UserWithEntitlement;
}

export function EditUserDialog({ user }: EditUserDialogProps) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  
  const formatDateForInput = (date: Date | string | null | undefined) => {
    if (!date) return "";
    const d = new Date(date);
    return format(d, "yyyy-MM-dd");
  };

  const [formData, setFormData] = useState({
    email: user.email,
    role: user.role,
    firstName: user.firstName || "",
    lastName: user.lastName || "",
    avatarUrl: user.avatarUrl || "",
    phone: user.phone || "",
    address: user.address || "",
    city: user.city || "",
    country: user.country || "",
    postalCode: user.postalCode || "",
    bankName: user.bankName || "",
    bankAccountNumber: user.bankAccountNumber || "",
    bankIban: user.bankIban || "",
    bankSwift: user.bankSwift || "",
    socialFacebook: user.socialFacebook || "",
    socialInstagram: user.socialInstagram || "",
    socialX: user.socialX || "",
    socialTiktok: user.socialTiktok || "",
    socialYoutube: user.socialYoutube || "",
    socialLinkedin: user.socialLinkedin || "",
    expiresAt: user.entitlement ? formatDateForInput(user.entitlement.expiresAt) : "",
  });

  useEffect(() => {
    if (open) {
      setFormData({
        email: user.email,
        role: user.role,
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        avatarUrl: user.avatarUrl || "",
        phone: user.phone || "",
        address: user.address || "",
        city: user.city || "",
        country: user.country || "",
        postalCode: user.postalCode || "",
        bankName: user.bankName || "",
        bankAccountNumber: user.bankAccountNumber || "",
        bankIban: user.bankIban || "",
        bankSwift: user.bankSwift || "",
        socialFacebook: user.socialFacebook || "",
        socialInstagram: user.socialInstagram || "",
        socialX: user.socialX || "",
        socialTiktok: user.socialTiktok || "",
        socialYoutube: user.socialYoutube || "",
        socialLinkedin: user.socialLinkedin || "",
        expiresAt: user.entitlement ? formatDateForInput(user.entitlement.expiresAt) : "",
      });
    }
  }, [user, open]);

  const updateUserMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const payload: any = {
        email: data.email,
        role: data.role,
        firstName: data.firstName,
        lastName: data.lastName,
        avatarUrl: data.avatarUrl,
        phone: data.phone,
        address: data.address,
        city: data.city,
        country: data.country,
        postalCode: data.postalCode,
        bankName: data.bankName,
        bankAccountNumber: data.bankAccountNumber,
        bankIban: data.bankIban,
        bankSwift: data.bankSwift,
        socialFacebook: data.socialFacebook,
        socialInstagram: data.socialInstagram,
        socialX: data.socialX,
        socialTiktok: data.socialTiktok,
        socialYoutube: data.socialYoutube,
        socialLinkedin: data.socialLinkedin,
      };
      
      if (data.expiresAt) {
        payload.expiresAt = new Date(data.expiresAt).toISOString();
      }
      
      const res = await apiRequest("PATCH", `/api/admin/users/${user.userId}`, payload);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Sukces!",
        description: "Użytkownik został zaktualizowany",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować użytkownika",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserMutation.mutate(formData);
  };

  const getInitials = () => {
    const first = formData.firstName || user.email[0] || "U";
    const last = formData.lastName?.[0] || "";
    return (first[0] + last).toUpperCase();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon"
          data-testid={`button-edit-user-${user.userId}`}
        >
          <Edit className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              <AvatarImage src={formData.avatarUrl} alt={formData.email} />
              <AvatarFallback className="text-lg">{getInitials()}</AvatarFallback>
            </Avatar>
            <div>
              <DialogTitle>Edytuj użytkownika</DialogTitle>
              <DialogDescription>
                ID: <span className="font-mono font-bold text-primary">{user.userId}</span>
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <Tabs defaultValue="personal" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="personal">Dane</TabsTrigger>
              <TabsTrigger value="contact">Kontakt</TabsTrigger>
              <TabsTrigger value="bank">Bank</TabsTrigger>
              <TabsTrigger value="social">Social</TabsTrigger>
              <TabsTrigger value="account">Konto</TabsTrigger>
            </TabsList>

            <TabsContent value="personal" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="flex items-center gap-2">
                    <UserIcon className="w-4 h-4" />
                    Imię
                  </Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder="Jan"
                    data-testid="input-user-first-name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lastName">Nazwisko</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder="Kowalski"
                    data-testid="input-user-last-name"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="avatarUrl" className="flex items-center gap-2">
                  <Image className="w-4 h-4" />
                  URL avatara
                </Label>
                <Input
                  id="avatarUrl"
                  type="url"
                  value={formData.avatarUrl}
                  onChange={(e) => setFormData({ ...formData, avatarUrl: e.target.value })}
                  placeholder="https://example.com/avatar.jpg"
                  data-testid="input-user-avatar-url"
                />
              </div>
            </TabsContent>

            <TabsContent value="contact" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  data-testid="input-user-email"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Telefon
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+48 123 456 789"
                  data-testid="input-user-phone"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Adres
                </Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="ul. Główna 123"
                  data-testid="input-user-address"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">Miasto</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Warszawa"
                    data-testid="input-user-city"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="postalCode">Kod pocztowy</Label>
                  <Input
                    id="postalCode"
                    value={formData.postalCode}
                    onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                    placeholder="00-000"
                    data-testid="input-user-postal-code"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="country">Kraj</Label>
                <Input
                  id="country"
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  placeholder="Polska"
                  data-testid="input-user-country"
                />
              </div>
            </TabsContent>

            <TabsContent value="bank" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="bankName" className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Nazwa banku
                </Label>
                <Input
                  id="bankName"
                  value={formData.bankName}
                  onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                  placeholder="PKO Bank Polski"
                  data-testid="input-user-bank-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bankAccountNumber">Numer konta</Label>
                <Input
                  id="bankAccountNumber"
                  value={formData.bankAccountNumber}
                  onChange={(e) => setFormData({ ...formData, bankAccountNumber: e.target.value })}
                  placeholder="12 3456 7890 1234 5678 9012 3456"
                  data-testid="input-user-bank-account-number"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bankIban">IBAN</Label>
                <Input
                  id="bankIban"
                  value={formData.bankIban}
                  onChange={(e) => setFormData({ ...formData, bankIban: e.target.value })}
                  placeholder="PL12 3456 7890 1234 5678 9012 3456"
                  data-testid="input-user-bank-iban"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bankSwift">SWIFT/BIC</Label>
                <Input
                  id="bankSwift"
                  value={formData.bankSwift}
                  onChange={(e) => setFormData({ ...formData, bankSwift: e.target.value })}
                  placeholder="BPKOPLPW"
                  data-testid="input-user-bank-swift"
                />
              </div>
            </TabsContent>

            <TabsContent value="social" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="socialFacebook" className="flex items-center gap-2">
                  <SiFacebook className="w-4 h-4" />
                  Facebook
                </Label>
                <Input
                  id="socialFacebook"
                  value={formData.socialFacebook}
                  onChange={(e) => setFormData({ ...formData, socialFacebook: e.target.value })}
                  placeholder="https://facebook.com/username"
                  data-testid="input-user-social-facebook"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="socialInstagram" className="flex items-center gap-2">
                  <SiInstagram className="w-4 h-4" />
                  Instagram
                </Label>
                <Input
                  id="socialInstagram"
                  value={formData.socialInstagram}
                  onChange={(e) => setFormData({ ...formData, socialInstagram: e.target.value })}
                  placeholder="https://instagram.com/username"
                  data-testid="input-user-social-instagram"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="socialX" className="flex items-center gap-2">
                  <SiX className="w-4 h-4" />
                  X (Twitter)
                </Label>
                <Input
                  id="socialX"
                  value={formData.socialX}
                  onChange={(e) => setFormData({ ...formData, socialX: e.target.value })}
                  placeholder="https://x.com/username"
                  data-testid="input-user-social-x"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="socialTiktok" className="flex items-center gap-2">
                  <SiTiktok className="w-4 h-4" />
                  TikTok
                </Label>
                <Input
                  id="socialTiktok"
                  value={formData.socialTiktok}
                  onChange={(e) => setFormData({ ...formData, socialTiktok: e.target.value })}
                  placeholder="https://tiktok.com/@username"
                  data-testid="input-user-social-tiktok"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="socialYoutube" className="flex items-center gap-2">
                  <SiYoutube className="w-4 h-4" />
                  YouTube
                </Label>
                <Input
                  id="socialYoutube"
                  value={formData.socialYoutube}
                  onChange={(e) => setFormData({ ...formData, socialYoutube: e.target.value })}
                  placeholder="https://youtube.com/@username"
                  data-testid="input-user-social-youtube"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="socialLinkedin" className="flex items-center gap-2">
                  <SiLinkedin className="w-4 h-4" />
                  LinkedIn
                </Label>
                <Input
                  id="socialLinkedin"
                  value={formData.socialLinkedin}
                  onChange={(e) => setFormData({ ...formData, socialLinkedin: e.target.value })}
                  placeholder="https://linkedin.com/in/username"
                  data-testid="input-user-social-linkedin"
                />
              </div>
            </TabsContent>

            <TabsContent value="account" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="role">Rola</Label>
                <Select
                  value={formData.role}
                  onValueChange={(value) => setFormData({ ...formData, role: value })}
                >
                  <SelectTrigger id="role" data-testid="select-user-role">
                    <SelectValue placeholder="Wybierz rolę" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USER">USER</SelectItem>
                    <SelectItem value="ADMIN">ADMIN</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expiresAt" className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Data wygaśnięcia dostępu
                </Label>
                <Input
                  id="expiresAt"
                  type="date"
                  value={formData.expiresAt}
                  onChange={(e) => setFormData({ ...formData, expiresAt: e.target.value })}
                  data-testid="input-user-expires-at"
                />
                <p className="text-sm text-muted-foreground">
                  Pozostaw puste jeśli nie chcesz zmieniać. Ustaw datę w przyszłości aby przyznać/przedłużyć dostęp.
                </p>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter className="mt-6">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setOpen(false)}
              data-testid="button-cancel-edit-user"
            >
              Anuluj
            </Button>
            <Button 
              type="submit" 
              disabled={updateUserMutation.isPending}
              data-testid="button-save-user"
            >
              {updateUserMutation.isPending ? "Zapisywanie..." : "Zapisz zmiany"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
